import type { ParsedSubtitle, SubtitleEntry } from "./types"

// Mock parsed subtitle data
export const mockParsedSubtitle: ParsedSubtitle = {
  id: "parsed1",
  name: "Inception (2010) Bilingual",
  format: "srt",
  languages: ["English", "Chinese"],
  entries: [
    {
      id: "entry1",
      index: 1,
      startTime: "00:00:02,000",
      endTime: "00:00:06,000",
      text: "Wake up.",
      language: "English",
    },
    {
      id: "entry2",
      index: 2,
      startTime: "00:00:02,000",
      endTime: "00:00:06,000",
      text: "醒来。",
      language: "Chinese",
    },
    {
      id: "entry3",
      index: 3,
      startTime: "00:00:08,000",
      endTime: "00:00:10,000",
      text: "Wake up, Cobb.",
      language: "English",
    },
    {
      id: "entry4",
      index: 4,
      startTime: "00:00:08,000",
      endTime: "00:00:10,000",
      text: "醒来，科布。",
      language: "Chinese",
    },
    {
      id: "entry5",
      index: 5,
      startTime: "00:00:12,000",
      endTime: "00:00:14,000",
      text: "How would you separate reality from a dream?",
      language: "English",
    },
    {
      id: "entry6",
      index: 6,
      startTime: "00:00:12,000",
      endTime: "00:00:14,000",
      text: "你如何区分现实和梦境？",
      language: "Chinese",
    },
    {
      id: "entry7",
      index: 7,
      startTime: "00:00:16,000",
      endTime: "00:00:18,000",
      text: "A totem.",
      language: "English",
    },
    {
      id: "entry8",
      index: 8,
      startTime: "00:00:16,000",
      endTime: "00:00:18,000",
      text: "一个图腾。",
      language: "Chinese",
    },
    {
      id: "entry9",
      index: 9,
      startTime: "00:00:20,000",
      endTime: "00:00:22,000",
      text: "An elegant solution for keeping track of reality.",
      language: "English",
    },
    {
      id: "entry10",
      index: 10,
      startTime: "00:00:20,000",
      endTime: "00:00:22,000",
      text: "一个追踪现实的优雅解决方案。",
      language: "Chinese",
    },
    {
      id: "entry11",
      index: 11,
      startTime: "00:00:25,000",
      endTime: "00:00:28,000",
      text: "You're waiting for a train.",
      language: "English",
    },
    {
      id: "entry12",
      index: 12,
      startTime: "00:00:25,000",
      endTime: "00:00:28,000",
      text: "你在等一列火车。",
      language: "Chinese",
    },
    {
      id: "entry13",
      index: 13,
      startTime: "00:00:29,000",
      endTime: "00:00:32,000",
      text: "A train that will take you far away.",
      language: "English",
    },
    {
      id: "entry14",
      index: 14,
      startTime: "00:00:29,000",
      endTime: "00:00:32,000",
      text: "一列将带你远行的火车。",
      language: "Chinese",
    },
    {
      id: "entry15",
      index: 15,
      startTime: "00:00:33,000",
      endTime: "00:00:36,000",
      text: "You know where you hope this train will take you.",
      language: "English",
    },
    {
      id: "entry16",
      index: 16,
      startTime: "00:00:33,000",
      endTime: "00:00:36,000",
      text: "你知道你希望这列火车会带你去哪里。",
      language: "Chinese",
    },
  ],
  scenes: {
    "time-based": [
      {
        id: "scene1-time",
        entries: [
          {
            id: "entry1",
            index: 1,
            startTime: "00:00:02,000",
            endTime: "00:00:06,000",
            text: "Wake up.",
            language: "English",
          },
          {
            id: "entry3",
            index: 3,
            startTime: "00:00:08,000",
            endTime: "00:00:10,000",
            text: "Wake up, Cobb.",
            language: "English",
          },
        ],
        startTime: "00:00:02,000",
        endTime: "00:00:10,000",
        language: "English",
      },
      {
        id: "scene2-time",
        entries: [
          {
            id: "entry5",
            index: 5,
            startTime: "00:00:12,000",
            endTime: "00:00:14,000",
            text: "How would you separate reality from a dream?",
            language: "English",
          },
          {
            id: "entry7",
            index: 7,
            startTime: "00:00:16,000",
            endTime: "00:00:18,000",
            text: "A totem.",
            language: "English",
          },
          {
            id: "entry9",
            index: 9,
            startTime: "00:00:20,000",
            endTime: "00:00:22,000",
            text: "An elegant solution for keeping track of reality.",
            language: "English",
          },
        ],
        startTime: "00:00:12,000",
        endTime: "00:00:22,000",
        language: "English",
      },
      {
        id: "scene3-time",
        entries: [
          {
            id: "entry11",
            index: 11,
            startTime: "00:00:25,000",
            endTime: "00:00:28,000",
            text: "You're waiting for a train.",
            language: "English",
          },
          {
            id: "entry13",
            index: 13,
            startTime: "00:00:29,000",
            endTime: "00:00:32,000",
            text: "A train that will take you far away.",
            language: "English",
          },
          {
            id: "entry15",
            index: 15,
            startTime: "00:00:33,000",
            endTime: "00:00:36,000",
            text: "You know where you hope this train will take you.",
            language: "English",
          },
        ],
        startTime: "00:00:25,000",
        endTime: "00:00:36,000",
        language: "English",
      },
      {
        id: "scene1-time-zh",
        entries: [
          {
            id: "entry2",
            index: 2,
            startTime: "00:00:02,000",
            endTime: "00:00:06,000",
            text: "醒来。",
            language: "Chinese",
          },
          {
            id: "entry4",
            index: 4,
            startTime: "00:00:08,000",
            endTime: "00:00:10,000",
            text: "醒来，科布。",
            language: "Chinese",
          },
        ],
        startTime: "00:00:02,000",
        endTime: "00:00:10,000",
        language: "Chinese",
      },
      {
        id: "scene2-time-zh",
        entries: [
          {
            id: "entry6",
            index: 6,
            startTime: "00:00:12,000",
            endTime: "00:00:14,000",
            text: "你如何区分现实和梦境？",
            language: "Chinese",
          },
          {
            id: "entry8",
            index: 8,
            startTime: "00:00:16,000",
            endTime: "00:00:18,000",
            text: "一个图腾。",
            language: "Chinese",
          },
          {
            id: "entry10",
            index: 10,
            startTime: "00:00:20,000",
            endTime: "00:00:22,000",
            text: "一个追踪现实的优雅解决方案。",
            language: "Chinese",
          },
        ],
        startTime: "00:00:12,000",
        endTime: "00:00:22,000",
        language: "Chinese",
      },
      {
        id: "scene3-time-zh",
        entries: [
          {
            id: "entry12",
            index: 12,
            startTime: "00:00:25,000",
            endTime: "00:00:28,000",
            text: "你在等一列火车。",
            language: "Chinese",
          },
          {
            id: "entry14",
            index: 14,
            startTime: "00:00:29,000",
            endTime: "00:00:32,000",
            text: "一列将带你远行的火车。",
            language: "Chinese",
          },
          {
            id: "entry16",
            index: 16,
            startTime: "00:00:33,000",
            endTime: "00:00:36,000",
            text: "你知道你希望这列火车会带你去哪里。",
            language: "Chinese",
          },
        ],
        startTime: "00:00:25,000",
        endTime: "00:00:36,000",
        language: "Chinese",
      },
    ],
    "character-based": [
      {
        id: "scene1-char",
        entries: [
          {
            id: "entry1",
            index: 1,
            startTime: "00:00:02,000",
            endTime: "00:00:06,000",
            text: "Wake up.",
            language: "English",
          },
          {
            id: "entry3",
            index: 3,
            startTime: "00:00:08,000",
            endTime: "00:00:10,000",
            text: "Wake up, Cobb.",
            language: "English",
          },
        ],
        startTime: "00:00:02,000",
        endTime: "00:00:10,000",
        language: "English",
      },
      {
        id: "scene2-char",
        entries: [
          {
            id: "entry5",
            index: 5,
            startTime: "00:00:12,000",
            endTime: "00:00:14,000",
            text: "How would you separate reality from a dream?",
            language: "English",
          },
        ],
        startTime: "00:00:12,000",
        endTime: "00:00:14,000",
        language: "English",
      },
      {
        id: "scene3-char",
        entries: [
          {
            id: "entry7",
            index: 7,
            startTime: "00:00:16,000",
            endTime: "00:00:18,000",
            text: "A totem.",
            language: "English",
          },
          {
            id: "entry9",
            index: 9,
            startTime: "00:00:20,000",
            endTime: "00:00:22,000",
            text: "An elegant solution for keeping track of reality.",
            language: "English",
          },
        ],
        startTime: "00:00:16,000",
        endTime: "00:00:22,000",
        language: "English",
      },
      {
        id: "scene4-char",
        entries: [
          {
            id: "entry11",
            index: 11,
            startTime: "00:00:25,000",
            endTime: "00:00:28,000",
            text: "You're waiting for a train.",
            language: "English",
          },
          {
            id: "entry13",
            index: 13,
            startTime: "00:00:29,000",
            endTime: "00:00:32,000",
            text: "A train that will take you far away.",
            language: "English",
          },
          {
            id: "entry15",
            index: 15,
            startTime: "00:00:33,000",
            endTime: "00:00:36,000",
            text: "You know where you hope this train will take you.",
            language: "English",
          },
        ],
        startTime: "00:00:25,000",
        endTime: "00:00:36,000",
        language: "English",
      },
      {
        id: "scene1-char-zh",
        entries: [
          {
            id: "entry2",
            index: 2,
            startTime: "00:00:02,000",
            endTime: "00:00:06,000",
            text: "醒来。",
            language: "Chinese",
          },
          {
            id: "entry4",
            index: 4,
            startTime: "00:00:08,000",
            endTime: "00:00:10,000",
            text: "醒来，科布。",
            language: "Chinese",
          },
        ],
        startTime: "00:00:02,000",
        endTime: "00:00:10,000",
        language: "Chinese",
      },
      {
        id: "scene2-char-zh",
        entries: [
          {
            id: "entry6",
            index: 6,
            startTime: "00:00:12,000",
            endTime: "00:00:14,000",
            text: "你如何区分现实和梦境？",
            language: "Chinese",
          },
        ],
        startTime: "00:00:12,000",
        endTime: "00:00:14,000",
        language: "Chinese",
      },
      {
        id: "scene3-char-zh",
        entries: [
          {
            id: "entry8",
            index: 8,
            startTime: "00:00:16,000",
            endTime: "00:00:18,000",
            text: "一个图腾。",
            language: "Chinese",
          },
          {
            id: "entry10",
            index: 10,
            startTime: "00:00:20,000",
            endTime: "00:00:22,000",
            text: "一个追踪现实的优雅解决方案。",
            language: "Chinese",
          },
        ],
        startTime: "00:00:16,000",
        endTime: "00:00:22,000",
        language: "Chinese",
      },
      {
        id: "scene4-char-zh",
        entries: [
          {
            id: "entry12",
            index: 12,
            startTime: "00:00:25,000",
            endTime: "00:00:28,000",
            text: "你在等一列火车。",
            language: "Chinese",
          },
          {
            id: "entry14",
            index: 14,
            startTime: "00:00:29,000",
            endTime: "00:00:32,000",
            text: "一列将带你远行的火车。",
            language: "Chinese",
          },
          {
            id: "entry16",
            index: 16,
            startTime: "00:00:33,000",
            endTime: "00:00:36,000",
            text: "你知道你希望这列火车会带你去哪里。",
            language: "Chinese",
          },
        ],
        startTime: "00:00:25,000",
        endTime: "00:00:36,000",
        language: "Chinese",
      },
    ],
    "dialog-based": [
      {
        id: "scene1-dialog",
        entries: [
          {
            id: "entry1",
            index: 1,
            startTime: "00:00:02,000",
            endTime: "00:00:06,000",
            text: "Wake up.",
            language: "English",
          },
          {
            id: "entry3",
            index: 3,
            startTime: "00:00:08,000",
            endTime: "00:00:10,000",
            text: "Wake up, Cobb.",
            language: "English",
          },
          {
            id: "entry5",
            index: 5,
            startTime: "00:00:12,000",
            endTime: "00:00:14,000",
            text: "How would you separate reality from a dream?",
            language: "English",
          },
        ],
        startTime: "00:00:02,000",
        endTime: "00:00:14,000",
        language: "English",
      },
      {
        id: "scene2-dialog",
        entries: [
          {
            id: "entry7",
            index: 7,
            startTime: "00:00:16,000",
            endTime: "00:00:18,000",
            text: "A totem.",
            language: "English",
          },
          {
            id: "entry9",
            index: 9,
            startTime: "00:00:20,000",
            endTime: "00:00:22,000",
            text: "An elegant solution for keeping track of reality.",
            language: "English",
          },
        ],
        startTime: "00:00:16,000",
        endTime: "00:00:22,000",
        language: "English",
      },
      {
        id: "scene3-dialog",
        entries: [
          {
            id: "entry11",
            index: 11,
            startTime: "00:00:25,000",
            endTime: "00:00:28,000",
            text: "You're waiting for a train.",
            language: "English",
          },
          {
            id: "entry13",
            index: 13,
            startTime: "00:00:29,000",
            endTime: "00:00:32,000",
            text: "A train that will take you far away.",
            language: "English",
          },
          {
            id: "entry15",
            index: 15,
            startTime: "00:00:33,000",
            endTime: "00:00:36,000",
            text: "You know where you hope this train will take you.",
            language: "English",
          },
        ],
        startTime: "00:00:25,000",
        endTime: "00:00:36,000",
        language: "English",
      },
      {
        id: "scene1-dialog-zh",
        entries: [
          {
            id: "entry2",
            index: 2,
            startTime: "00:00:02,000",
            endTime: "00:00:06,000",
            text: "醒来。",
            language: "Chinese",
          },
          {
            id: "entry4",
            index: 4,
            startTime: "00:00:08,000",
            endTime: "00:00:10,000",
            text: "醒来，科布。",
            language: "Chinese",
          },
          {
            id: "entry6",
            index: 6,
            startTime: "00:00:12,000",
            endTime: "00:00:14,000",
            text: "你如何区分现实和梦境？",
            language: "Chinese",
          },
        ],
        startTime: "00:00:02,000",
        endTime: "00:00:14,000",
        language: "Chinese",
      },
      {
        id: "scene2-dialog-zh",
        entries: [
          {
            id: "entry8",
            index: 8,
            startTime: "00:00:16,000",
            endTime: "00:00:18,000",
            text: "一个图腾。",
            language: "Chinese",
          },
          {
            id: "entry10",
            index: 10,
            startTime: "00:00:20,000",
            endTime: "00:00:22,000",
            text: "一个追踪现实的优雅解决方案。",
            language: "Chinese",
          },
        ],
        startTime: "00:00:16,000",
        endTime: "00:00:22,000",
        language: "Chinese",
      },
      {
        id: "scene3-dialog-zh",
        entries: [
          {
            id: "entry12",
            index: 12,
            startTime: "00:00:25,000",
            endTime: "00:00:28,000",
            text: "你在等一列火车。",
            language: "Chinese",
          },
          {
            id: "entry14",
            index: 14,
            startTime: "00:00:29,000",
            endTime: "00:00:32,000",
            text: "一列将带你远行的火车。",
            language: "Chinese",
          },
          {
            id: "entry16",
            index: 16,
            startTime: "00:00:33,000",
            endTime: "00:00:36,000",
            text: "你知道你希望这列火车会带你去哪里。",
            language: "Chinese",
          },
        ],
        startTime: "00:00:25,000",
        endTime: "00:00:36,000",
        language: "Chinese",
      },
    ],
  },
}

export function parseSubtitle(content: string, format: string): ParsedSubtitle {
  // In a real app, this would parse the subtitle content
  // For now, we'll just return the mock data
  return mockParsedSubtitle
}

export function detectLanguages(content: string): string[] {
  // In a real app, this would detect languages in the subtitle
  // For now, we'll just return the mock languages
  return mockParsedSubtitle.languages
}

export function separateLanguages(parsedSubtitle: ParsedSubtitle, language: string): SubtitleEntry[] {
  // Filter entries by language
  return parsedSubtitle.entries.filter((entry) => entry.language === language)
}

export function exportSubtitle(entries: SubtitleEntry[], format: string): string {
  // In a real app, this would convert entries back to the specified format
  // For now, we'll just return a simple string representation
  let result = ""

  if (format === "srt") {
    entries.forEach((entry) => {
      result += `${entry.index}\n`
      result += `${entry.startTime} --> ${entry.endTime}\n`
      result += `${entry.text}\n\n`
    })
  } else if (format === "ass") {
    result = "[Script Info]\n"
    result += "Title: Exported Subtitle\n"
    result += "ScriptType: v4.00+\n\n"
    result += "[Events]\n"
    result += "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"

    entries.forEach((entry) => {
      const start = entry.startTime.replace(",", ".")
      const end = entry.endTime.replace(",", ".")
      result += `Dialogue: 0,${start},${end},Default,,0,0,0,,${entry.text}\n`
    })
  }

  return result
}
