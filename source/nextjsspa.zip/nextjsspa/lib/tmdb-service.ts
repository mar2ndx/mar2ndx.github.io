import { MovieCredit } from './types';
const TMDB_API_KEY = process.env.TMDB_API_KEY;
// const TMDB_BASE_URL = 'https://api.themoviedb.org/3'; TODO: enable this

if (!TMDB_API_KEY) {
  console.warn(
    'Warning: TMDB_API_KEY environment variable is not set. TMDb features will not work.'
  );
}

interface TmdbMovieSearchResult {
  id: number;
  title: string;
  poster_path: string | null;
  release_date: string;
  overview: string;
}

interface TmdbMovieSearchResponse {
  page: number;
  results: TmdbMovieSearchResult[];
  total_pages: number;
  total_results: number;
}

interface TmdbMovieDetails {
    id: number;
    title: string;
    poster_path: string | null;
    backdrop_path: string | null;
    release_date: string;
    overview: string;
    genres: { id: number; name: string }[];
    vote_average: number;
    imdb_id: string | null;
}

async function fetchTmdb(endpoint: string, params: Record<string, string> = {}) {
  if (!TMDB_API_KEY) {
    throw new Error('TMDB_API_KEY is not configured.');
  }

  const url = new URL(`${TMDB_BASE_URL}${endpoint}`);
  url.searchParams.append('api_key', TMDB_API_KEY);
  Object.entries(params).forEach(([key, value]) => {
    url.searchParams.append(key, value);
  });

  try {
    const response = await fetch(url.toString());
    if (!response.ok) {
      const errorData = await response.json();
      console.error('TMDb API Error:', errorData);
      throw new Error(`TMDb API request failed with status ${response.status}: ${errorData.status_message || 'Unknown error'}`);
    }
    return await response.json();
  } catch (error) {
    console.error('Error fetching from TMDb:', error);
    throw error; // Re-throw the error after logging
  }
}

/**
 * Searches for movies on TMDb by query.
 */
export async function searchMovies(query: string): Promise<TmdbMovieSearchResult[]> {
  if (!query) return [];
  const data: TmdbMovieSearchResponse = await fetchTmdb('/search/movie', { query });
  return data.results || [];
}

/**
 * Fetches detailed information for a specific movie by its TMDb ID.
 */
export async function getMovieDetails(movieId: number): Promise<TmdbMovieDetails | null> {
  if (!movieId) return null;
  try {
    const data: TmdbMovieDetails = await fetchTmdb(`/movie/${movieId}`);
    return data;
  } catch (error) {
    // Handle cases where the movie might not be found (e.g., 404) or other errors
    console.error(`Error fetching details for movie ID ${movieId}:`, error);
    return null;
  }
}

/**
 * Finds a movie on TMDb using an external ID (like IMDb ID).
 * Note: This endpoint returns results grouped by type (movie_results, tv_results, etc.).
 */
export async function findByExternalId(externalId: string, source: 'imdb_id' = 'imdb_id'): Promise<TmdbMovieSearchResult | null> {
  if (!externalId) return null;
  try {
    // The 'find' endpoint returns a structure like { movie_results: [...], tv_results: [...] }
    const data = await fetchTmdb(`/find/${externalId}`, { external_source: source });
    // Assuming we only care about movie results and take the first one if multiple exist
    if (data.movie_results && data.movie_results.length > 0) {
      // The find endpoint might return slightly different fields than search, ensure consistency if needed
      // For now, we assume it returns at least id, title, poster_path
      return data.movie_results[0] as TmdbMovieSearchResult;
    }
    return null;
  } catch (error) {
    console.error(`Error finding movie by external ID ${externalId}:`, error);
    return null;
  }
}
/**
 * Fetches the cast credits for a specific movie by its TMDb ID.
 */
export async function getMovieCredits(movieId: number): Promise<MovieCredit[]> {
  if (!movieId) return [];
  try {
    // The standard TMDb credits endpoint returns { id: number, cast: [...], crew: [...] }
    // We assume the user's provided example structure corresponds to the items in the 'cast' array.
    const data = await fetchTmdb(`/movie/${movieId}/credits`);

    // Validate the structure before casting
    if (data && Array.isArray(data.cast)) {
       // TODO: Add more robust validation or mapping if the API structure
       // differs significantly from the MovieCredit interface.
       // For now, we cast directly based on the user's example.
      return data.cast as MovieCredit[];
    }
    console.warn(`No cast data found or invalid format for movie ID ${movieId}`);
    return []; // Return empty array if cast data is missing or not an array
  } catch (error) {
    console.error(`Error fetching credits for movie ID ${movieId}:`, error);
    return []; // Return empty array on error
  }
}


/**
 * Constructs the full URL for a TMDb image path.
 * @param path The poster or backdrop path from the TMDb API response.
 * @param size The desired image size (e.g., 'w500', 'original'). Defaults to 'w500'.
 * @returns The full image URL or null if the path is invalid.
 */
export function getTmdbImageUrl(path: string | null | undefined, size: string = 'w500'): string | null {
  if (!path) {
    return null; // Or return a placeholder image URL
  }
  return `${TMDB_IMAGE_BASE_URL}${size}${path}`;
}