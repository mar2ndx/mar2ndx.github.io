import type { Movie, Subtitle } from "./types"

/**
 * Fetches random recommended movies from the API
 * @param count Number of movies to fetch (default: 6)
 * @returns Array of Movie objects
 */
export async function fetchRecommendedMovies(count: number = 6): Promise<Movie[]> {
  try {
    const response = await fetch(`http://localhost:8001/list/random?count=${count}`, {
      headers: {
        'accept': 'application/json'
      },
      cache: 'no-store' // Ensure we get fresh data each time
    });
    
    if (!response.ok) {
      console.error(`Error fetching recommended movies: ${response.status}`);
      return [];
    }
    
    const data = await response.json();
    
    if (!Array.isArray(data) || data.length === 0) {
      console.error("No movies found or invalid response format");
      return [];
    }
    
    // Map the API response to match our Movie interface
    return data.map((movie: any) => ({
      id: movie.tconst,
      title: movie.primary_title,
      year: movie.start_year || 0,
      imdbId: movie.tconst,
      doubanId: "", // API doesn't provide Douban ID
      posterUrl: `/images/poster/${movie.tconst}.jpg`, // Assuming poster naming convention
      description: `${movie.primary_title} (${movie.start_year}) - ${movie.genres.join(', ')}. Rating: ${movie.average_rating}/10 from ${movie.num_votes} votes.`
    }));
  } catch (error) {
    console.error("Error fetching recommended movies:", error);
    return [];
  }
}

// API functions for subtitles
/**
 * Fetches subtitles only from the local database for a specific movie
 * @param imdbId The IMDB ID of the movie
 * @returns Array of Subtitle objects found in the DB, or empty array if none found/error
 */
export async function getSubtitlesFromDB(imdbId: string): Promise<Subtitle[]> {
  try {
    const response = await fetch(`http://localhost:8001/subtitles/db/${imdbId}`, {
      headers: {
        'accept': 'application/json'
      },
      cache: 'no-store' // Ensure we get fresh data
    });

    if (!response.ok) {
      // If 404, it just means no subtitles in DB, return empty array
      if (response.status === 404) {
        return [];
      }
      console.error(`Error fetching DB subtitles: ${response.status}`);
      return []; // Return empty on other errors too
    }

    const data = await response.json();

    if (!Array.isArray(data)) {
      console.error("Invalid response format from DB subtitles endpoint");
      return [];
    }

    if (data.length === 0) {
      return []; // No subtitles found in DB
    }

    // Transform the API response into Subtitle objects (assuming similar structure)
    // TODO: Adjust mapping if the DB endpoint returns a different structure
    return data.map((subtitle: any, index: number) => {
      const fileName = subtitle.filename?.split('/').pop() || `db-subtitle-${index}`;
      const format = fileName.toLowerCase().endsWith('.ass') ? 'ass' : 'srt';
      const yearMatch = (subtitle.shooter_title || fileName).match(/\b(19|20)\d{2}\b/);
      const year = yearMatch ? parseInt(yearMatch[0]) : 0;

      return {
        id: `db-${imdbId}-${subtitle.id || index}`, // Use subtitle ID if available
        name: fileName,
        format,
        language: subtitle.language || "Unknown",
        downloads: subtitle.downloads || 0,
        source: "Database",
        preview: `Preview not available`,
        url: subtitle.url || '', // Use URL if available
        movieInfo: {
          title: subtitle.shooter_title || 'Unknown Title',
          year: year,
          imdbId,
          doubanId: ""
        },
        isDefault: subtitle.is_default_en || subtitle.is_default_cn || false
      };
    });
  } catch (error) {
    console.error("Error fetching DB subtitles:", error);
    return [];
  }
}

export async function setAsDefault(id: string, language: string): Promise<void> {
  // Simulate setting as default
  await new Promise((resolve) => setTimeout(resolve, 500))

  // In a real app, this would update the database
  console.log(`Setting subtitle with ID: ${id} as default for language: ${language}`)
}

/**
 * Fetches subtitles from external sources (like Assrt.net) and potentially stores them.
 * Uses the /subtitles/fetch/{imdb_id} endpoint.
 * @param imdbId The IMDB ID of the movie
 * @param limit Optional maximum number of results to fetch/store
 * @returns Array of Subtitle objects fetched
 */
export async function fetchAndStoreSubtitles(imdbId: string, limit?: number): Promise<Subtitle[]> {
  try {
    // Construct URL with optional limit parameter
    let url = `http://localhost:8001/subtitles/fetch/${imdbId}`;
    if (limit !== undefined) {
      url += `?limit=${limit}`;
    }
    const response = await fetch(url, {
      headers: {
        'accept': 'application/json'
      },
      cache: 'no-store' // Ensure we get fresh data
    });
    
    if (!response.ok) {
      console.error(`Error fetching/storing subtitles: ${response.status}`);
      return [];
    }
    
    const data = await response.json();
    
    if (!Array.isArray(data) || data.length === 0) {
      console.error("No subtitles found or invalid response format from fetch endpoint");
      return [];
    }
    
    // Transform the API response into Subtitle objects
    return data.map((subtitle: any, index: number) => {
      // Extract filename from path
      const fileName = subtitle.filename.split('/').pop() || '';
      
      // Determine format from file extension
      const format = fileName.toLowerCase().endsWith('.ass') ? 'ass' : 'srt';
      
      // Extract movie title from shooter_title or filename
      // const movieTitle = subtitle.shooter_title
      //   ? subtitle.shooter_title
      //   : fileName.split('.')[0];
      
      // Try to extract year from filename or shooter_title
      const yearMatch = (subtitle.shooter_title || fileName).match(/\b(19|20)\d{2}\b/);
      const year = yearMatch ? parseInt(yearMatch[0]) : 0;
      
      return {
        id: `assrt-${imdbId}-${index}`,
        name: fileName,
        format,
        language: subtitle.language || "Unknown",
        downloads: 0, // No download count from API
        source: "Assrt.net",
        preview: `Preview not available`, // Preview not available from API
        url: subtitle.url, // Using the API-provided URL
        movieInfo: {
          title: subtitle.shooter_title,
          year: year,
          imdbId,
          doubanId: ""
        },
        isDefault: subtitle.is_default_en || subtitle.is_default_cn || false
      };
    });
  } catch (error) {
    console.error("Error fetching/storing subtitles:", error);
    return [];
  }
}

