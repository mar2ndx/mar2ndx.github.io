export interface MovieInfo {
  title: string
  year: number
  imdbId: string
  doubanId: string
}

export interface MovieSearchResult {
  tconst: string
  title_type: string
  primary_title: string
  original_title: string
  is_adult: boolean
  start_year: number | null
  end_year: number | null
  runtime_minutes: number | null
  genres: string[]
  average_rating: number | null
  num_votes: number | null
}
export interface Movie {
  id: string
  title: string
  year: number
  imdbId: string
  doubanId: string
  posterUrl: string
  description: string
}

export interface Subtitle {
  id: string
  name: string
  format: string // 'srt' or 'ass'
  language: string
  downloads: number
  source: string
  preview: string
  url: string
  movieInfo: MovieInfo
  isDefault?: boolean
}

export interface SubtitleEntry {
  id: string
  index: number
  startTime: string
  endTime: string
  text: string
  language: string
}

export interface SubtitleScene {
  id: string
  entries: SubtitleEntry[]
  startTime: string
  endTime: string
  language: string
}

export type GroupingAlgorithm = "time-based" | "character-based" | "dialog-based"

export interface ParsedSubtitle {
  id: string
  name: string
  format: string
  entries: SubtitleEntry[]
  scenes: {
    [algorithm in GroupingAlgorithm]: SubtitleScene[]
  }
  languages: string[]
}

export interface MovieCredit {
  tconst: string;
  ordering: number;
  nconst: string;
  category: string;
  job: string | null;
  characters: string[] | null;
  primary_name: string;
  birth_year: number | null;
  death_year: number | null;
  primary_profession: string[] | null;
  known_for_titles: string[] | null;
}
