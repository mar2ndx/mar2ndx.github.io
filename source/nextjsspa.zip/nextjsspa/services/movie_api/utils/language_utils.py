# services/movie_api/utils/language_utils.py

import re
from typing import Dict

# Language code to human-readable name mapping
LANGUAGE_DISPLAY_NAMES: Dict[str, str] = {
    "chs": "Chinese (Simplified)",
    "cht": "Chinese (Traditional)",
    "en": "English",
    "unknown": "Unknown"
}

def detect_subtitle_language(filename: str) -> str:
    """
    Detect the language of a subtitle file based on its filename.
    
    Args:
        filename: The filename of the subtitle file
        
    Returns:
        The detected language code: "cht", "chs", "en", or "unknown"
    """
    filename_lower = filename.lower()
    
    # Check for explicit language indicators in filename
    if any(marker in filename_lower for marker in ["繁体", "繁體", "cht", "繁", "繁中", "hant"]):
        return "cht"
    
    if any(marker in filename_lower for marker in ["简体", "簡體", "chs", "简", "简中", "中文", "hans"]):
        return "chs"
    
    if any(marker in filename_lower for marker in ["英文", "英语", "eng", "en", "english"]):
        return "en"
    
    # Check for dual language indicators and take the first one
    dual_lang_patterns = [
        r"(繁体|繁體|cht|繁|繁中)[&+._ -]*(英文|eng|en|english)",
        r"(简体|簡體|chs|简|简中|中文)[&+._ -]*(英文|eng|en|english)",
        r"(英文|eng|en|english)[&+._ -]*(繁体|繁體|cht|繁|繁中)",
        r"(英文|eng|en|english)[&+._ -]*(简体|簡體|chs|简|简中|中文)"
    ]
    
    for pattern in dual_lang_patterns:
        match = re.search(pattern, filename_lower)
        if match:
            first_lang = match.group(1)
            if any(marker in first_lang for marker in ["繁体", "繁體", "cht", "繁", "繁中"]):
                return "cht"
            if any(marker in first_lang for marker in ["简体", "簡體", "chs", "简", "简中", "中文"]):
                return "chs"
            if any(marker in first_lang for marker in ["英文", "eng", "en", "english"]):
                return "en"
    
    # Default to "unknown" if no language indicators found
    return "unknown"

def get_language_display_name(language_code: str) -> str:
    """
    Get the human-readable display name for a language code.
    
    Args:
        language_code: The language code (e.g., "chs", "cht", "en")
        
    Returns:
        The human-readable display name for the language
    """
    return LANGUAGE_DISPLAY_NAMES.get(language_code, "Unknown")