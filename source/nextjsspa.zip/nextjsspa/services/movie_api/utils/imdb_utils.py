# services/movie_api/utils/imdb_utils.py

from fastapi import HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from typing import Tuple
from packages.models.imdb import TitleBasics

async def get_movie_title_and_year_by_imdb_id(imdb_id: str, db: AsyncSession) -> Tuple[str, int]:
    """
    Fetches the primary title and start year for a given IMDB ID from the database.

    Args:
        imdb_id: The IMDB ID (tconst) to search for.
        db: The async database session.

    Returns:
        A tuple containing the primary title (str) and start year (int).

    Raises:
        HTTPException: If the IMDB ID is not found (404) or year is missing.
    """
    stmt = select(TitleBasics.primary_title, TitleBasics.start_year).where(TitleBasics.tconst == imdb_id)
    result = await db.execute(stmt)
    movie_record = result.one_or_none() # Fetch the row

    if not movie_record:
        print(f"Error: IMDB ID '{imdb_id}' not found in the database.")
        raise HTTPException(status_code=404, detail=f"IMDB ID '{imdb_id}' not found.")

    movie_title, movie_year = movie_record
    if not movie_year:
         print(f"Error: Start year not found for IMDB ID '{imdb_id}'.")
         raise HTTPException(status_code=404, detail=f"Start year not found for IMDB ID '{imdb_id}'.")


    return movie_title, movie_year