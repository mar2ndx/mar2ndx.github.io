
# services/movie_api/utils/subtitle_utils.py

import re
import os
import tempfile
import shutil
import zipfile
import subprocess
import hashlib
import logging
from pathlib import Path
from urllib.parse import urljoin
import traceback
import httpx
from bs4 import BeautifulSoup
from typing import List, Set, Tuple, Dict, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.exc import IntegrityError

from ..schemas import SrtSearchResult
from packages.models.media import SubtitleFile, SubtitleDuplicate
from ..config import SRT_SAVE_DIR
from .language_utils import detect_subtitle_language

# Configure logging
logger = logging.getLogger(__name__)

def calculate_file_hash(file_path: str) -> bytes:
    """
    Calculate SHA-256 hash of a file.
    
    Args:
        file_path: Path to the file
        
    Returns:
        SHA-256 hash of the file as binary data (bytes)
    """
    try:
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            # Read and update hash in chunks of 4K
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.digest()  # Return binary digest instead of hexadecimal string
    except Exception as e:
        logger.error(f"Error calculating hash for {file_path}: {str(e)}")
        return b""  # Return empty bytes object on error

async def find_subtitle_by_hash(db: AsyncSession, file_hash: bytes) -> SubtitleFile:
    """
    Find a subtitle file by its hash value.
    
    Args:
        db: The database session
        file_hash: The hash value to search for
        
    Returns:
        The SubtitleFile object if found, None otherwise
    """
    query = select(SubtitleFile).where(SubtitleFile.file_hash == file_hash)
    result = await db.execute(query)
    return result.scalar_one_or_none()

async def search_assrt_subtitles(search_string: str) -> List[SrtSearchResult]:
    """
    Search assrt.net for subtitles using the provided search string.
    
    Args:
        search_string: The search string to use for finding subtitles
        
    Returns:
        A list of SrtSearchResult objects containing the search results
    """
    search_results = []
    allowed_formats = {"ssa", "srt", "subrip"}  # Case-insensitive check later
    search_url = f"https://2.assrt.net/sub/?searchword={search_string}"
    
    headers = {  # Mimic browser headers
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }

    async with httpx.AsyncClient(timeout=10.0) as client:
        response = await client.get(
            search_url, headers=headers, follow_redirects=True
        )
        response.raise_for_status()  # Raise exception for bad status codes

    soup = BeautifulSoup(response.text, "html.parser")
    
    # First get the sublist_box_title_l class elements
    title_spans = soup.select("span.sublist_box_title_l")
    links = []
    
    # Then get the introtitle inside each span
    for span in title_spans:
        link = span.select_one("a.introtitle")
        if link:
            # Check if this item has a "Pack" tag and skip it if found
            parent_div = span.find_parent("div")
            if parent_div:
                pack_tag = parent_div.find("span", class_="smart_tag pack_tag", title="剧集打包")
                if pack_tag:
                    # Skip this item as it has a Pack tag
                    continue
            links.append(link)

    for link in links:
        container = None
        current = link
        for _ in range(5):  # Check up to 5 levels up for a suitable div
            parent = current.find_parent("div")
            if parent and parent.find("div", id="meta_top"):
                container = parent
                break
            if not parent:
                break  # Stop if no more parents
            current = parent

        if not container:
            title_span = link.find_parent("span", class_="sublist_box_title_l")
            if title_span:
                meta_top = title_span.find_next_sibling("div", id="meta_top")
            else:
                meta_top = None
        else:
            meta_top = container.find("div", id="meta_top")

        if not meta_top:
            print(f"Warning: Could not find #meta_top for link: {link.get('href')}")
            continue

        format_span = meta_top.find_next_sibling("span")
        if not format_span:
            temp_span = meta_top.find_next_sibling()
            if temp_span:
                format_span = temp_span.find_next_sibling("span")

        if not format_span:
            print(
                f"Warning: Could not find format span for link: {link.get('href')}"
            )
            continue

        format_text = format_span.get_text(strip=True)
        file_format = ""
        if format_text.startswith("格式："):
            file_format = format_text.replace("格式：", "").strip().lower()
            if "subrip" in file_format or "srt" in file_format:
                file_format = "srt"
            elif "ssa" in file_format:
                file_format = "ssa"
            else:
                file_format = ""

        if file_format in allowed_formats:
            title = link.get("title", "").strip()
            href = link.get("href", "").strip()
            xml_link = (
                f"https://2.assrt.net{href}" if href.startswith("/") else href
            )

            if title and xml_link:
                search_results.append(
                    SrtSearchResult(
                        source="assrt.net", file_name=title, xml_page_link=xml_link
                    )
                )
    
    return search_results
async def find_download_link(xml_page_url: str) -> Optional[str]:
    """
    Find the download link on the subtitle detail page.
    
    Args:
        xml_page_url: The URL of the subtitle detail page
        
    Returns:
        The absolute download URL if found, None otherwise
    """
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }
    
    async with httpx.AsyncClient(timeout=20.0, headers=headers, follow_redirects=True) as client:
        xml_response = await client.get(xml_page_url)
        xml_response.raise_for_status()

    soup_detail = BeautifulSoup(xml_response.text, "html.parser")
    download_button = None
    
    try:
        # 1. Try finding by specific text content (more reliable than ID)
        potential_links_text = soup_detail.find_all(
            "a", string=re.compile(r"下载字幕")
        )  # Search for "下载字幕"
        if potential_links_text:
            print(
                f"Found download link(s) by text '下载字幕': {[link.get('href') for link in potential_links_text]}"
            )
            download_button = potential_links_text[0]  # Take the first one

        # 2. If not found by text, try finding by href starting with /download/
        if not download_button:
            potential_links_href = soup_detail.find_all(
                "a", href=re.compile(r"^/download/")
            )
            if potential_links_href:
                print(
                    f"Found download link(s) by href pattern '/download/': {[link.get('href') for link in potential_links_href]}"
                )
                download_button = potential_links_href[0]  # Take the first one

        # 3. Fallback: Try finding by common archive extensions in href
        if not download_button:
            potential_links_ext = soup_detail.find_all(
                "a",
                href=re.compile(
                    r"\.(zip|rar|7z|srt|ass)$", re.IGNORECASE
                ),  # Added srt/ass
            )
            if potential_links_ext:
                print(
                    f"Found potential download link(s) via file extension: {[link.get('href') for link in potential_links_ext]}"
                )
                download_button = potential_links_ext[0]  # Take the first one

    except Exception as parse_err:
        print(
            f"Warning: Error during download link parsing for {xml_page_url}: {parse_err}."
        )
        return None

    # Final check if any link was found
    if not download_button:
        print(
            f"Error: Could not find download button or any suitable fallback link on {xml_page_url}."
        )
        return None

    relative_download_path = download_button.get("href")
    if not relative_download_path:
        print(
            f"Error: Download button on {xml_page_url} has no href attribute."
        )
        return None

    base_url = "https://2.assrt.net"
    absolute_download_url = urljoin(base_url, relative_download_path)
    size_em = download_button.find("em", id="downsubbtnfsize")
    file_size = size_em.get_text(strip=True) if size_em else "Unknown size"
    print(f"Found download link: {absolute_download_url} (Size: {file_size})")
    
    return absolute_download_url

def normalize_filename(filename: str) -> str:
    """
    Normalize a filename by replacing problematic characters with their Unicode equivalents.
    
    Args:
        filename: The filename to normalize
        
    Returns:
        The normalized filename
    """
    try:
        # Try to normalize the filename using NFKD normalization
        import unicodedata
        normalized = unicodedata.normalize('NFKD', filename)
        
        # Replace any remaining non-ASCII characters with their hex representation
        result = ""
        for char in normalized:
            if ord(char) < 128:  # ASCII characters
                result += char
            else:
                # For non-ASCII, keep the original if it's a common CJK character
                # Otherwise replace with a safe representation
                if '\u4e00' <= char <= '\u9fff':  # Common CJK Unified Ideographs
                    result += char
                else:
                    result += f"_{ord(char):x}_"  # Hex representation
        
        return result
    except Exception as e:
        print(f"Error normalizing filename: {e}")
        return filename  # Return original if normalization fails

# Language detection moved to language_utils.py
async def download_and_process_subtitle(
    download_url: str,
    dest_dir: Path,
    result: SrtSearchResult,
    existing_filenames_in_db: Set[str],
    imdb_id: str,
    db: AsyncSession
) -> Tuple[List[str], List[str], int]:
    """
    Download and process a subtitle file from the given URL.
    
    Args:
        download_url: The URL to download the subtitle file from
        dest_dir: The destination directory to save the extracted files
        result: The search result object containing metadata
        existing_filenames_in_db: Set of existing filenames in database to avoid duplicates
        imdb_id: The IMDB ID for the movie
        db: The database session
        
    Returns:
        A tuple containing (processed_files, errors, successful_downloads)
    """
    processed_files = []
    errors = []
    successful_downloads = 0
    temp_dir = None
    
    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
        
        temp_dir = tempfile.mkdtemp(prefix="movie_srt_")
        print(f"Created temporary directory: {temp_dir}")
        # Get the original filename from the URL
        downloaded_filename = Path(download_url).name
        
        # Sanitize filename (replace spaces with underscores)
        downloaded_filename = re.sub(r"\s+", "_", downloaded_filename)
        
        # Handle long filenames by truncating if necessary
        # Extract the file extension
        file_ext = os.path.splitext(downloaded_filename)[1]
        filename_base = os.path.splitext(downloaded_filename)[0]
        
        # Limit the base filename to a reasonable length (max 100 chars)
        # This prevents "filename too long" errors
        if len(filename_base) > 100:
            # Safely display the filename in logs
            safe_display_name = filename_base.encode('utf-8', errors='replace').decode('utf-8')
            print(f"Truncating long filename: {safe_display_name[:30]}...{safe_display_name[-30:]} -> {safe_display_name[:97]}...")
            filename_base = filename_base[:97] + "..."
            
            # Normalize the filename to handle special characters
            filename_base = normalize_filename(filename_base)
        
        # Reconstruct the filename with the original extension
        downloaded_filename = filename_base + file_ext
        
        # Create the temporary file path
        temp_file_path = Path(temp_dir) / downloaded_filename

        async with httpx.AsyncClient(timeout=60.0, follow_redirects=True) as client:
            async with client.stream("GET", download_url) as response:
                response.raise_for_status()
                with open(temp_file_path, "wb") as f:
                    async for chunk in response.aiter_bytes():
                        f.write(chunk)
        print(f"Downloaded file to: {temp_file_path}")

        extract_dir = Path(temp_dir)
        extracted_archive = False
        file_suffix = temp_file_path.suffix.lower()

        if file_suffix == ".zip":
            print(f"Detected .zip extension for {temp_file_path.name}, attempting extraction...")
            try:
                if not zipfile.is_zipfile(temp_file_path):
                    print(f"Warning: File {temp_file_path.name} has .zip extension but is_zipfile returned False. Attempting extraction anyway.")
                with zipfile.ZipFile(temp_file_path, "r") as zip_ref:
                    # Handle non-ASCII filenames in ZIP
                    for zip_info in zip_ref.infolist():
                        try:
                            # Try to decode the filename with cp437 (ZIP standard) and encode to utf-8
                            filename = zip_info.filename.encode('cp437').decode('utf-8')
                        except UnicodeEncodeError:
                            # If already UTF-8, this will fail, so just use the original
                            filename = zip_info.filename
                        except UnicodeDecodeError:
                            # If decoding fails, try other common encodings
                            for encoding in ['gbk', 'big5', 'utf-8']:
                                try:
                                    filename = zip_info.filename.encode('cp437').decode(encoding)
                                    break
                                except (UnicodeEncodeError, UnicodeDecodeError):
                                    continue
                            else:
                                # If all decodings fail, use raw filename
                                filename = zip_info.filename
                        
                        # Extract the file with the decoded name
                        zip_info.filename = filename
                        zip_ref.extract(zip_info, extract_dir)
                
                print(f"Extracted ZIP contents to: {extract_dir}")
                extracted_archive = True
            except zipfile.BadZipFile:
                print(f"Error: Bad/Corrupted ZIP file ({temp_file_path.name}). Skipping.")
                errors.append(f"Corrupted ZIP for {result.file_name}")
                return processed_files, errors, successful_downloads
            except Exception as zip_e:
                print(f"Error extracting ZIP file ({temp_file_path.name}): {zip_e}. Skipping.")
                errors.append(f"Failed to extract ZIP for {result.file_name}: {zip_e}")
                return processed_files, errors, successful_downloads
        elif file_suffix == ".rar":
            print(f"Detected .rar extension for {temp_file_path.name}, attempting extraction using 'unar'...")
            try:
                dest_path_str = str(extract_dir)
                archive_path_str = str(temp_file_path)
                command = ["unar", "-f", "-o", dest_path_str, archive_path_str]
                print(f"Executing command: {' '.join(command)}")
                result_proc = subprocess.run(
                    command, capture_output=True, text=True, check=True, timeout=120
                )
                print(f"RAR extraction successful:\n{result_proc.stdout}")
                extracted_archive = True
            except FileNotFoundError:
                print("Error: 'unar' command not found. Skipping RAR.")
                errors.append("'unar' not found, cannot extract RAR")
                return processed_files, errors, successful_downloads
            except subprocess.TimeoutExpired:
                print(f"Error: RAR extraction timed out for {temp_file_path}. Skipping.")
                errors.append(f"RAR extraction timed out for {result.file_name}")
                return processed_files, errors, successful_downloads
            except subprocess.CalledProcessError as rar_e:
                print(f"Error during RAR extraction: {rar_e}. Stderr: {rar_e.stderr}. Skipping.")
                errors.append(f"Failed to extract RAR for {result.file_name}: {rar_e.stderr}")
                return processed_files, errors, successful_downloads
            except Exception as rar_generic_e:
                print(f"An unexpected error occurred during RAR extraction: {rar_generic_e}. Skipping.")
                errors.append(f"Unexpected error extracting RAR for {result.file_name}: {rar_generic_e}")
                return processed_files, errors, successful_downloads
        elif file_suffix in [".srt", ".ass"]:
            print(f"File {temp_file_path.name} has {file_suffix} extension. Assuming direct subtitle file.")
            try:
                original_name = temp_file_path.name
                
                # Normalize the filename to handle special characters
                original_name = normalize_filename(original_name)
                
                # Handle long filenames for direct subtitle files
                file_ext = os.path.splitext(original_name)[1]
                filename_base = os.path.splitext(original_name)[0]
                
                if len(filename_base) > 100:
                    # Safely display the filename in logs
                    safe_display_name = filename_base.encode('utf-8', errors='replace').decode('utf-8')
                    print(f"Truncating long subtitle filename: {safe_display_name[:30]}...{safe_display_name[-30:]} -> {safe_display_name[:97]}...")
                    filename_base = filename_base[:97] + "..."
                    original_name = filename_base + file_ext

                # Calculate file hash
                file_hash = calculate_file_hash(str(temp_file_path))
                # Convert binary hash to hex string for display only
                hex_hash = file_hash.hex() if file_hash else ""
                print(f"Calculated hash for {original_name}: {hex_hash}")
                
                # --- Check if filename already exists in database ---
                if original_name in existing_filenames_in_db:
                    print(f"Skipping direct file: Filename '{original_name}' already exists in database")
                    return processed_files, errors, successful_downloads

                dest_file_path = dest_dir / original_name
                # Ensure destination path is absolute before moving
                absolute_dest_path = dest_file_path.resolve()
                # Fix encoding issues before saving the file
                try:
                    # Try to read the file with different encodings
                    encodings_to_try = ['utf-8', 'utf-16', 'latin-1', 'cp1252', 'gbk', 'big5', 'cp437', 'shift_jis']
                    content = None
                    
                    with open(str(temp_file_path), 'rb') as f:
                        raw_content = f.read()
                    
                    # Try to detect encoding
                    try:
                        import chardet
                        detection = chardet.detect(raw_content)
                        detected_encoding = detection["encoding"]
                        confidence = detection["confidence"]
                        
                        print(f"Detected encoding for {original_name}: {detected_encoding} with confidence: {confidence}")
                        
                        if detected_encoding and confidence > 0.7:
                            encodings_to_try.insert(0, detected_encoding)  # Try detected encoding first
                    except ImportError:
                        print("chardet not available, using default encoding list")
                    
                    # Try each encoding
                    for encoding in encodings_to_try:
                        try:
                            content = raw_content.decode(encoding)
                            print(f"Successfully decoded {original_name} with {encoding}")
                            break
                        except UnicodeDecodeError:
                            continue
                    
                    # If all encodings fail, use raw content
                    if content is None:
                        print(f"Warning: Could not decode {original_name} with any encoding, using raw content")
                        # Just move the file as is
                        shutil.move(str(temp_file_path), str(absolute_dest_path))
                    else:
                        # Write with UTF-8 encoding
                        with open(str(absolute_dest_path), 'w', encoding='utf-8') as f:
                            f.write(content)
                except Exception as e:
                    print(f"Error handling encoding for {original_name}: {str(e)}")
                    # Fall back to simple move
                    shutil.move(str(temp_file_path), str(absolute_dest_path))
                # Detect language
                language = detect_subtitle_language(original_name)

                # --- Check if file with same hash already exists ---
                original_subtitle = await find_subtitle_by_hash(db, file_hash)
                
                if original_subtitle:
                    # Found a duplicate hash, record it in the subtitle_duplicate table
                    logger.warning(f"Duplicate content detected: '{original_name}' has the same hash as an existing file")
                    print(f"Found file with same hash in database, recording as duplicate")
                    
                    # Record the duplicate in the subtitle_duplicate table
                    duplicate_entry = SubtitleDuplicate(
                        file_hash=file_hash,
                        original_imdb_id=original_subtitle.imdb_id,
                        original_filename=original_subtitle.filename,
                        original_download_timestamp=original_subtitle.download_timestamp,
                        original_source_url=original_subtitle.source_url,
                        duplicate_imdb_id=imdb_id,
                        duplicate_filename=original_name,
                        duplicate_source_url=result.xml_page_link
                    )
                    
                    try:
                        db.add(duplicate_entry)
                        await db.flush()
                        print(f"Recorded duplicate subtitle: original={original_subtitle.imdb_id}/{original_subtitle.filename}, duplicate={imdb_id}/{original_name}")
                        
                        # Add to processed files since we've recorded the duplicate
                        processed_files.append(f"{imdb_id}/{original_name}")
                        successful_downloads += 1
                        
                        # Keep the file since we've recorded it as a duplicate
                        print(f"Keeping duplicate file: {original_name}")
                    except Exception as dup_e:
                        logger.error(f"Error recording duplicate subtitle: {str(dup_e)}")
                        print(f"Error recording duplicate subtitle: {str(dup_e)}")
                        errors.append(f"Error recording duplicate: {str(dup_e)}")
                else:
                    # No duplicate found, proceed with normal insertion
                    subtitle_entry = SubtitleFile(
                        imdb_id=imdb_id,
                        filename=original_name,
                        shooter_title=result.file_name,
                        source_url=result.xml_page_link,
                        format=file_suffix.strip("."),  # e.g., 'srt' or 'ass'
                        language=language,
                        file_hash=file_hash
                    )
                    
                    try:
                        db.add(subtitle_entry)
                        await db.flush()
                        
                        # If we get here, the insert was successful
                        # Safely display the filename in logs
                        safe_display_name = original_name.encode('utf-8', errors='replace').decode('utf-8')
                        print(f"Logged new subtitle file to DB: {imdb_id}/{safe_display_name}")
        
                        # Add to lists and increment count
                        processed_files.append(f"{imdb_id}/{original_name}")
                        successful_downloads += 1
                        # Safely display the filename in logs
                        safe_display_name = dest_file_path.name.encode('utf-8', errors='replace').decode('utf-8')
                        print(f"Saved direct file {safe_display_name}")
                    except IntegrityError as e:
                        # This should rarely happen now, but handle it just in case
                        logger.warning(f"Database integrity error when inserting subtitle file: {str(e)}")
                        print(f"Error inserting subtitle file: {str(e)}")
                        errors.append(f"Database error: {str(e)}")

                return processed_files, errors, successful_downloads
            except Exception as move_e:
                print(f"Warning: Failed to move assumed subtitle file {temp_file_path.name}: {move_e}")
                errors.append(f"Failed to move assumed subtitle {temp_file_path.name}: {move_e}")
                return processed_files, errors, successful_downloads
        else:
            print(f"Error: File {temp_file_path.name} has unrecognized extension '{file_suffix}'. Skipping.")
            errors.append(f"Unrecognized file type for {result.file_name}: {temp_file_path.name}")
            return processed_files, errors, successful_downloads

        # Process extracted archive if needed
        if extracted_archive:
            print(f"Searching for extracted subtitle files in: {extract_dir}")
            found_files = list(extract_dir.rglob("*.srt"))
            is_srt = bool(found_files)  # Remember if we found SRT
            if not found_files:
                print("No .srt files found after extraction, searching for .ass files...")
                found_files = list(extract_dir.rglob("*.ass"))
                is_srt = False  # Mark that we are now using ASS
            if not found_files:
                print(f"Error: No .srt or .ass files found after extracting archive for {result.file_name}. Skipping.")
                errors.append(f"No .srt/.ass files found post-extraction for {result.file_name}")
                return processed_files, errors, successful_downloads

            # Properly display filenames in logs
            file_names = []
            for f in found_files:
                try:
                    file_names.append(f.name)
                except UnicodeEncodeError:
                    # If there's an encoding error when displaying the name, show a placeholder
                    file_names.append(f"<filename with encoding issues: {f.name.encode('utf-8', errors='replace').decode('utf-8')}>")
            
            print(f"Found extracted subtitle files: {file_names}")
            
            # --- Filter out unwanted English subtitles if too many SRT results ---
            if is_srt and len(found_files) > 3:
                print(f"Found {len(found_files)} SRT files initially. Filtering out '&英文'/'英文&' named files...")
                initial_count = len(found_files)
                found_files = [
                    f for f in found_files
                    if "&英文" not in f.name and "英文&" not in f.name
                ]
                filtered_count = len(found_files)
                print(f"Filtered down to {filtered_count} SRT files from {initial_count}.")
                # Re-check if filtering left any files
                if not found_files:
                    print(f"Error: All {initial_count} SRT files were filtered out for {result.file_name}. Skipping.")
                    errors.append(f"All {initial_count} SRT files filtered out for {result.file_name}")
                    return processed_files, errors, successful_downloads
                print(f"Using filtered SRT files: {[f.name for f in found_files]}")
            # --- End Filter ---

            moved_files_count = 0
            for file_path in found_files:
                try:
                    original_name = file_path.name
                    
                    # Normalize the filename to handle special characters
                    original_name = normalize_filename(original_name)
                    
                    # Handle long filenames for extracted subtitle files
                    file_ext = os.path.splitext(original_name)[1]
                    filename_base = os.path.splitext(original_name)[0]
                    
                    if len(filename_base) > 100:
                        # Safely display the filename in logs
                        safe_display_name = filename_base.encode('utf-8', errors='replace').decode('utf-8')
                        print(f"Truncating long extracted filename: {safe_display_name[:30]}...{safe_display_name[-30:]} -> {safe_display_name[:97]}...")
                        filename_base = filename_base[:97] + "..."
                        original_name = filename_base + file_ext

                    # Calculate file hash
                    file_hash = calculate_file_hash(str(file_path))
                    # Convert binary hash to hex string for display only
                    hex_hash = file_hash.hex() if file_hash else ""
                    print(f"Calculated hash for {original_name}: {hex_hash}")
                    
                    # --- Check if filename already exists in database ---
                    if original_name in existing_filenames_in_db:
                        print(f"Skipping extracted file: Filename '{original_name}' already exists in database")
                        continue  # Skip this file

                    dest_file_path = dest_dir / original_name
                    # Ensure destination path is absolute before moving
                    absolute_dest_path = dest_file_path.resolve()
                    # Fix encoding issues before saving the file
                    try:
                        # Try to read the file with different encodings
                        encodings_to_try = ['utf-8', 'utf-16', 'latin-1', 'cp1252', 'gbk', 'big5', 'cp437', 'shift_jis']
                        content = None
                        
                        with open(str(file_path), 'rb') as f:
                            raw_content = f.read()
                        
                        # Try to detect encoding
                        try:
                            import chardet
                            detection = chardet.detect(raw_content)
                            detected_encoding = detection["encoding"]
                            confidence = detection["confidence"]
                            
                            print(f"Detected encoding for {original_name}: {detected_encoding} with confidence: {confidence}")
                            
                            if detected_encoding and confidence > 0.7:
                                encodings_to_try.insert(0, detected_encoding)  # Try detected encoding first
                        except ImportError:
                            print("chardet not available, using default encoding list")
                        
                        # Try each encoding
                        for encoding in encodings_to_try:
                            try:
                                content = raw_content.decode(encoding)
                                print(f"Successfully decoded {original_name} with {encoding}")
                                break
                            except UnicodeDecodeError:
                                continue
                        
                        # If all encodings fail, use raw content
                        if content is None:
                            print(f"Warning: Could not decode {original_name} with any encoding, using raw content")
                            # Just move the file as is
                            shutil.move(str(file_path), str(absolute_dest_path))
                        else:
                            # Write with UTF-8 encoding
                            with open(str(absolute_dest_path), 'w', encoding='utf-8') as f:
                                f.write(content)
                    except Exception as e:
                        print(f"Error handling encoding for {original_name}: {str(e)}")
                        # Fall back to simple move
                        shutil.move(str(file_path), str(absolute_dest_path))
                    # Detect language
                    language = detect_subtitle_language(original_name)

                    # --- Check if file with same hash already exists ---
                    original_subtitle = await find_subtitle_by_hash(db, file_hash)
                    
                    if original_subtitle:
                        # Found a duplicate hash, record it in the subtitle_duplicate table
                        logger.warning(f"Duplicate content detected: '{original_name}' has the same hash as an existing file")
                        print(f"Found file with same hash in database, recording as duplicate")
                        
                        # Record the duplicate in the subtitle_duplicate table
                        duplicate_entry = SubtitleDuplicate(
                            file_hash=file_hash,
                            original_imdb_id=original_subtitle.imdb_id,
                            original_filename=original_subtitle.filename,
                            original_download_timestamp=original_subtitle.download_timestamp,
                            original_source_url=original_subtitle.source_url,
                            duplicate_imdb_id=imdb_id,
                            duplicate_filename=original_name,
                            duplicate_source_url=result.xml_page_link
                        )
                        
                        try:
                            db.add(duplicate_entry)
                            await db.flush()
                            print(f"Recorded duplicate subtitle: original={original_subtitle.imdb_id}/{original_subtitle.filename}, duplicate={imdb_id}/{original_name}")
                            
                            # Add to processed files since we've recorded the duplicate
                            processed_files.append(f"{imdb_id}/{original_name}")
                            moved_files_count += 1
                            
                            # Keep the file since we've recorded it as a duplicate
                            print(f"Keeping duplicate file: {original_name}")
                        except Exception as dup_e:
                            logger.error(f"Error recording duplicate subtitle: {str(dup_e)}")
                            print(f"Error recording duplicate subtitle: {str(dup_e)}")
                    else:
                        # No duplicate found, proceed with normal insertion
                        subtitle_entry = SubtitleFile(
                            imdb_id=imdb_id,
                            filename=original_name,
                            shooter_title=result.file_name,  # Use the name from the search result
                            source_url=result.xml_page_link,
                            format=file_path.suffix.strip("."),  # e.g., 'srt' or 'ass'
                            language=language,
                            file_hash=file_hash
                        )
                        
                        try:
                            db.add(subtitle_entry)
                            await db.flush()
                            
                            # If we get here, the insert was successful
                            # Safely display the filename in logs
                            safe_display_name = original_name.encode('utf-8', errors='replace').decode('utf-8')
                            print(f"Logged new subtitle file to DB: {imdb_id}/{safe_display_name}")
        
                            # Add to lists and increment count
                            processed_files.append(f"{imdb_id}/{original_name}")
                            moved_files_count += 1
                            # Safely display the filename in logs
                            safe_display_name = dest_file_path.name.encode('utf-8', errors='replace').decode('utf-8')
                            print(f"Saved extracted file {safe_display_name}")
                        except IntegrityError as e:
                            # This should rarely happen now, but handle it just in case
                            logger.warning(f"Database integrity error when inserting subtitle file: {str(e)}")
                            print(f"Error inserting subtitle file: {str(e)}")
                except Exception as move_e:
                    print(f"Warning: Failed to move extracted file {file_path.name}: {move_e}")
                    errors.append(f"Failed to move extracted {file_path.name}: {move_e}")

            if moved_files_count > 0:
                successful_downloads += 1
                print(f"Processed {moved_files_count} file(s) from archive {result.file_name}.")
            else:
                print(f"Warning: No files were ultimately processed for archive {result.file_name}, despite finding some initially.")
                errors.append(f"No files ultimately saved from {result.file_name}")
    
    finally:
        # Clean up temporary directory
        if temp_dir and os.path.exists(temp_dir):
            try:
                shutil.rmtree(temp_dir)
                print(f"Cleaned up temporary directory: {temp_dir}")
            except Exception as clean_e:
                print(f"Warning: Failed to clean up temporary directory {temp_dir}: {clean_e}")
    
    return processed_files, errors, successful_downloads