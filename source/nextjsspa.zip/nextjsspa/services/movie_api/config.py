from pathlib import Path

# Configuration settings for the Movie API

# Directory to store downloaded and extracted SRT files
# The structure will be SRT_SAVE_DIR / imdb_id / file.srt
SRT_SAVE_DIR = Path("/Users/Shared/hub/nextjs-spa/public/data/srt_files")

# Ensure the directory exists (optional, but good practice)
# SRT_SAVE_DIR.mkdir(parents=True, exist_ok=True) # Uncomment if needed, might have permission issues depending on deployment