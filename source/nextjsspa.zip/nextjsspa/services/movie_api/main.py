from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from typing import List

# Import routers
from .routers.search import search_router
from .routers.movies import movies_router
from .routers.people import people_router
from .routers.subtitles import subtitles_router
from .routers.list import list_router

app = FastAPI(
    title="Movie Fans API",
    description="API for searching and retrieving movie, actor, and subtitle information.",
    version="1.0.0",
)

# --- CORS Middleware ---
# Allow requests from the frontend development server
origins = [
    "http://localhost:3000", # React default dev port
    # Add other origins if needed, e.g., your deployed frontend URL
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"], # Allows all methods
    allow_headers=["*"], # Allows all headers
)

# --- Startup Event ---


@app.on_event("startup")
async def startup_event():
    """
    Event handler that runs when the application starts up.
    Prints the documentation URL.
    """
    print("---")
    print("Movie API Documentation available at: http://localhost:8001/docs/")
    print("---")


# --- Include Routers ---
app.include_router(search_router)
app.include_router(movies_router)
app.include_router(people_router)
app.include_router(subtitles_router)
app.include_router(list_router)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("services.movie_api.main:app", host="0.0.0.0", port=8001, reload=True)
