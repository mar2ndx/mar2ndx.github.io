# Movie Fans API

A comprehensive API for searching and retrieving movie, actor, and subtitle information from IMDB and local databases.

## Features

- Search for movies by title
- Search for people by name
- Get detailed information about movies and people
- Search for movies associated with specific people
- Search, download, and manage subtitles for movies

## Getting Started

### Prerequisites

- Python 3.8+
- PostgreSQL database with IMDB data
- Required Python packages (see `requirements.txt`)

### Installation

1. Clone the repository
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Configure database connection in `packages/db/settings.py`
4. Run the API:
   ```
   python -m services.movie_api.main
   ```

## API Documentation

Once the API is running, you can access the interactive API documentation at:

```
http://localhost:8001/docs
```

## API Structure

The API is organized into the following logical groups:

### Movies

Endpoints for movie-related operations:

- `GET /movies/{imdb_id}` - Get movie details by IMDB ID
- `GET /movies/{imdb_id}/ratings` - Get movie ratings
- `GET /movies/{imdb_id}/credits` - Get movie cast and crew

### People

Endpoints for person-related operations:

- `GET /people/{nconst}` - Get person details by IMDB ID
- `GET /people/{nconst}/filmography` - Get person's filmography

### Subtitles

Endpoints for subtitle-related operations:

- `GET /subtitles/{imdb_id}` - Get subtitles for a movie (from database and assrt.net if needed)
- `GET /subtitles/download/{subtitle_id}` - Download a specific subtitle

### Search

Endpoints for search functionality:

- `GET /search/movies` - Search for movies by title
- `GET /search/people` - Search for people by name
- `GET /search/movies-by-person` - Search for movies associated with a person

## Examples

### Search for Movies

```
GET /search/movies?query=inception&limit=5
```

### Get Movie Details

```
GET /movies/tt1375666
```

### Get Subtitles for Movie

```
GET /subtitles/tt1375666?limit=5
```

## Development

### Project Structure

```
services/movie_api/
├── __init__.py
├── config.py - Configuration settings
├── main.py - FastAPI application and startup
├── schemas.py - Pydantic models for API
├── api_design.md - API design documentation
├── routers/ - API route handlers
│   ├── movies.py - Movie-related endpoints
│   ├── people.py - Person-related endpoints
│   ├── search.py - Search-related endpoints
│   └── subtitles.py - Subtitle-related endpoints
└── utils/ - Utility functions
    ├── imdb_utils.py - IMDB-related utilities
    └── subtitle_utils.py - Subtitle-related utilities
```

### Adding New Endpoints

1. Define the endpoint in the appropriate router file
2. Add any necessary schemas to `schemas.py`
3. Implement the endpoint logic
4. Update the API documentation

## License

This project is licensed under the MIT License - see the LICENSE file for details.