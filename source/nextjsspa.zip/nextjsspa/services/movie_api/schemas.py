# services/movie_api/schemas.py
from pydantic import BaseModel, Field
from typing import List, Optional, Union

# --- Schemas for /search Endpoint ---

class SrtSearchResult(BaseModel):
    source: str # e.g., "assrt.net", "opensubtitles.org"
    file_name: str
    xml_page_link: Optional[str] = None # Link to the XML/HTML page containing the download button

class SrtDownloadStatus(BaseModel):
    status: str # e.g., "success", "partial_success", "failure"
    message: str
    processed_files: List[str] = [] # List of paths relative to the data directory

class SubtitleInfo(BaseModel):
    language: str
    url: str
    filename: str
    is_default_cn: bool = False
    is_default_en: bool = False
    shooter_title: Optional[str] = None
    file_hash_hex: Optional[str] = None  # Hex string representation of the binary hash

class MovieSearchResult(BaseModel):
    tconst: str = Field(..., description="IMDb title constant ID")
    primary_title: str = Field(..., description="The most popular title")
    original_title: str = Field(..., description="Original title, in the original language")
    start_year: Optional[int] = Field(None, description="Represents the release year of a title")
    # Placeholder for subtitle info - will be populated later
    subtitles: List[SubtitleInfo] = Field([], description="List of available subtitles")

    class Config:
        from_attributes = True # Enable ORM mode for compatibility with SQLAlchemy models

# --- Schemas for /imdb Endpoints ---

class NameBasicInfo(BaseModel):
    nconst: str
    primary_name: str
    birth_year: Optional[int] = None
    death_year: Optional[int] = None
    primary_profession: Optional[List[str]] = None
    known_for_titles: Optional[List[str]] = None

    class Config:
        from_attributes = True

class TitleBasicInfo(BaseModel):
    tconst: str
    title_type: str
    primary_title: str
    original_title: str
    is_adult: Optional[bool] = None
    start_year: Optional[int] = None
    end_year: Optional[int] = None
    runtime_minutes: Optional[int] = None
    genres: Optional[List[str]] = None

    class Config:
        from_attributes = True

class TitleRatingInfo(BaseModel):
    tconst: str
    average_rating: Optional[float] = None # Using float for Numeric(3,1)
    num_votes: int

    class Config:
        from_attributes = True

class TitlePrincipalInfo(BaseModel):
    tconst: str
    ordering: int
    nconst: Optional[str] = None
    category: str
    job: Optional[str] = None
    characters: Optional[List[str]] = None # Assuming characters are stored as JSON list string

    class Config:
        from_attributes = True

class MovieWithRating(BaseModel):
    """Movie information with its IMDB rating"""
    # Basic movie information
    tconst: str
    title_type: str
    primary_title: str
    original_title: str
    is_adult: Optional[bool] = None
    start_year: Optional[int] = None
    end_year: Optional[int] = None
    runtime_minutes: Optional[int] = None
    genres: Optional[List[str]] = None
    
    # Rating information
    average_rating: Optional[float] = None
    num_votes: Optional[int] = None
    
    class Config:
        from_attributes = True

# Add other schemas as needed for crew, akas, episode etc.

class EnrichedTitlePrincipalInfo(BaseModel):
    """Enhanced movie credit information with person details"""
    # Title principal information
    tconst: str
    ordering: int
    nconst: Optional[str] = None
    category: str
    job: Optional[str] = None
    characters: Optional[List[str]] = None
    
    # Person information
    primary_name: Optional[str] = None
    birth_year: Optional[int] = None
    death_year: Optional[int] = None
    primary_profession: Optional[List[str]] = None
    known_for_titles: Optional[List[str]] = None
    
    class Config:
        from_attributes = True