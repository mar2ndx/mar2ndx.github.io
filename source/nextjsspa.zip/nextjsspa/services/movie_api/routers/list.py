from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import desc
from typing import List

from packages.db.database import get_db_session
from packages.models.imdb import TitleBasics, TitleRatings
from packages.models.media import SubtitleFile
from ..schemas import MovieWithRating

list_router = APIRouter(prefix="/list", tags=["Lists"])

@list_router.get("/random", response_model=List[MovieWithRating])
async def get_random_movies(
    count: int = Query(10, ge=1, le=100, description="Number of random movies to return"),
    db: AsyncSession = Depends(get_db_session)
):
    """
    Get a list of random movies that don't have subtitles, ordered by IMDB rating score in descending order.
    """
    # Subquery to get movies that have subtitles
    movies_with_subtitles = select(SubtitleFile.imdb_id).distinct()
    
    # Main query to get movies without subtitles, joined with ratings
    query = (
        select(TitleBasics, TitleRatings.average_rating, TitleRatings.num_votes)
        .outerjoin(TitleRatings, TitleBasics.tconst == TitleRatings.tconst)
        .where(TitleBasics.tconst.not_in(movies_with_subtitles))
        .where(TitleBasics.title_type == "movie")
        .where(TitleRatings.num_votes>=99000)
        .where(TitleRatings.average_rating.is_not(None))
        .order_by(desc(TitleRatings.average_rating))
        .limit(count)
    )
    
    result = await db.execute(query)
    rows = result.all()
    
    # Construct response with movie and rating information
    movies_with_ratings = []
    for row in rows:
        movie, avg_rating, num_votes = row
        
        # Create a dictionary with all movie attributes
        movie_dict = {
            "tconst": movie.tconst,
            "title_type": movie.title_type,
            "primary_title": movie.primary_title,
            "original_title": movie.original_title,
            "is_adult": movie.is_adult,
            "start_year": movie.start_year,
            "end_year": movie.end_year,
            "runtime_minutes": movie.runtime_minutes,
            "genres": movie.genres,
            
            # Add rating information
            "average_rating": avg_rating,
            "num_votes": num_votes
        }
        
        movies_with_ratings.append(MovieWithRating(**movie_dict))
    
    return movies_with_ratings