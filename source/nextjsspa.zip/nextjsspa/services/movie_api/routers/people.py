from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from typing import List, Optional

from packages.db.database import get_db_session
from packages.models.imdb import NameBasics, TitlePrincipals, TitleBasics
from ..schemas import NameBasicInfo, MovieSearchResult

people_router = APIRouter(prefix="/people", tags=["People"])

@people_router.get("/{nconst}", response_model=NameBasicInfo)
async def get_person(nconst: str, db: AsyncSession = Depends(get_db_session)):
    """
    Get detailed information about a person by their IMDB ID (nconst).
    """
    result = await db.execute(select(NameBasics).where(NameBasics.nconst == nconst))
    person = result.scalar_one_or_none()
    
    if person is None:
        raise HTTPException(
            status_code=404, detail=f"Person with IMDB ID '{nconst}' not found"
        )
    
    return person

@people_router.get("/{nconst}/filmography", response_model=List[MovieSearchResult])
async def get_person_filmography(
    nconst: str,
    category: Optional[str] = None,
    limit: int = Query(20, ge=1, le=100),
    sort: str = Query("year_desc", regex="^(year_asc|year_desc)$"),
    db: AsyncSession = Depends(get_db_session)
):
    """
    Get the filmography for a person by their IMDB ID (nconst).
    Optionally filter by category (e.g., "actor", "director").
    Sort by year in ascending or descending order.
    """
    # First verify the person exists
    person_exists = await db.execute(
        select(NameBasics.nconst).where(NameBasics.nconst == nconst)
    )
    if person_exists.scalar_one_or_none() is None:
        raise HTTPException(
            status_code=404, detail=f"Person with IMDB ID '{nconst}' not found"
        )
    
    # Build the query to join TitlePrincipals with TitleBasics
    query = (
        select(
            TitleBasics.tconst,
            TitleBasics.primary_title,
            TitleBasics.original_title,
            TitleBasics.start_year,
            TitlePrincipals.category
        )
        .join(
            TitlePrincipals,
            TitleBasics.tconst == TitlePrincipals.tconst
        )
        .where(TitlePrincipals.nconst == nconst)
    )
    
    # Apply category filter if provided
    if category:
        query = query.where(TitlePrincipals.category == category)
    
    # Apply sorting
    if sort == "year_asc":
        query = query.order_by(TitleBasics.start_year.asc().nullslast())
    else:  # year_desc is the default
        query = query.order_by(TitleBasics.start_year.desc().nullslast())
    
    # Add limit
    query = query.limit(limit)
    
    # Execute query
    result = await db.execute(query)
    movies_db = result.all()
    
    # Format results
    movies_result = [
        MovieSearchResult(
            tconst=movie.tconst,
            primary_title=movie.primary_title,
            original_title=movie.original_title,
            start_year=movie.start_year,
            subtitles=[],  # Placeholder
        )
        for movie in movies_db
    ]
    
    return movies_result