from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import text
from typing import List, Optional
from pathlib import Path
import os
import re
import traceback
import shutil

from packages.db.database import get_db_session
from packages.models.media import SubtitleFile, SubtitleSearchLog
from packages.models.imdb import TitleBasics
from ..schemas import SrtDownloadStatus, SubtitleInfo, SrtSearchResult
from ..utils.subtitle_utils import search_assrt_subtitles, find_download_link, download_and_process_subtitle
from ..utils.language_utils import detect_subtitle_language, get_language_display_name
from ..utils.imdb_utils import get_movie_title_and_year_by_imdb_id
from ..config import SRT_SAVE_DIR

subtitles_router = APIRouter(prefix="/subtitles", tags=["Subtitles"])

# Helper function for the main endpoint
async def search_and_download_subtitles(
    imdb_id: str,
    limit: int,
    db: AsyncSession
):
    """
    Searches assrt.net for subtitles using a generated search string based on the
    primary title and year associated with an IMDB ID.
    It first checks the database for existing subtitles for the given IMDB ID.
    If found, returns the existing file paths.
    Otherwise, proceeds to search assrt.net, downloads up to the specified 'limit'
    results (default 5), extracts if necessary, organizes .srt/.ass files into
    ./data/srt_files/{imdb_id}, and logs results to the DB.
    """
    print(f"Initiating download and organization for IMDB ID: {imdb_id} (limit={limit})")

    # --- Fetch movie title and year using utility ---
    movie_title, movie_year = await get_movie_title_and_year_by_imdb_id(imdb_id, db)
    print(f"Found movie title '{movie_title}' and year '{movie_year}' from IMDB database with ID {imdb_id}")

    # --- Generate Search String ---
    # 1. Remove special chars/digits, keep spaces, convert to lowercase
    clean_title = re.sub(r"[^a-zA-Z0-9\s]", "", movie_title).lower()

    # 2. Split into words
    words = clean_title.split()

    # 3. Select words 
    if len(words) >= 4:
        selected_words = words[:4]
        # Optional: check length condition based on potentially longer words now
        if len("".join(selected_words)) < 20 and len(words) >= 5:
            selected_words = words[:5]
    else:
        selected_words = words

    # 4. Append year and join with '+'
    search_terms = selected_words + [str(movie_year)]
    search_string = "+".join(search_terms)
    print(f"Convert IMDB ID {imdb_id} to search string: {search_string}")

    # --- Define destination directory and check existing files in database ---
    dest_dir = SRT_SAVE_DIR / imdb_id
    dest_dir.mkdir(parents=True, exist_ok=True)  # Ensure directory exists
    print(f"Checking for existing subtitles in database for IMDB ID: {imdb_id}")

    # Query the database for existing subtitle files
    query = select(SubtitleFile).where(SubtitleFile.imdb_id == imdb_id)
    result = await db.execute(query)
    existing_subtitle_files = result.scalars().all()
    
    existing_files_in_db = []
    existing_filenames_in_db = set()
    for subtitle in existing_subtitle_files:
        # Store just the filename for checking duplicates
        filename = os.path.basename(subtitle.filename)
        existing_filenames_in_db.add(filename)
        
        # Store the full path for return value
        existing_files_in_db.append(f"{imdb_id}/{filename}")
    
    existing_count = len(existing_files_in_db)
    print(f"Found {existing_count} existing subtitle file(s) in database for {imdb_id}.")

    # --- Check if limit is already met ---
    if existing_count >= limit:
        message = f"Limit ({limit}) already met. Found {existing_count} existing subtitle file(s) in database for {imdb_id}."
        print(message)
        # Log this scenario
        search_log_entry = SubtitleSearchLog(
            imdb_id=imdb_id,
            search_successful=True,  # Considered success as files exist
            message=message,
        )
        db.add(search_log_entry)
        return SrtDownloadStatus(
            status="success",
            message=message,
            processed_files=existing_files_in_db,  # Return files found in database with imdb_id prefix
        )
    else:
        print(f"Found {existing_count} files, which is less than the limit ({limit}). Proceeding to fetch.")

    # --- Proceed with Fetching from assrt.net ---
    search_log_entry = SubtitleSearchLog(
        imdb_id=imdb_id,
        search_successful=False,  # Placeholder, update after search
        message=f"Search initiated on assrt.net. Found {existing_count}/{limit} files initially.",
    )
    db.add(search_log_entry)
    await db.flush()  # Get the ID if needed, and ensure it's in the session

    try:
        # Search for subtitles
        search_results = await search_assrt_subtitles(search_string)
        
        # Update log based on whether search results were found
        search_log_entry.search_successful = bool(search_results)

        if not search_results:
            message = f"No suitable subtitle results found for search string '{search_string}' (derived from '{movie_title}', {imdb_id})."
            print(f"No suitable subtitle results found on assrt.net for search string '{search_string}' (IMDB ID: {imdb_id})")
            search_log_entry.message = message
            return SrtDownloadStatus(status="failure", message=message)

        # --- Process results (limit based on 'limit' parameter) ---
        all_processed_files = list(existing_files_in_db)  # Start with existing files from database
        errors = []
        successful_downloads = 0
        saved_file_count = existing_count  # Start count from existing files
        max_saved_files = limit  # Target number of files
        print(f"Attempting to reach {max_saved_files} subtitle files (currently have {saved_file_count})...")

        for result in search_results:
            # Check if we've already saved enough files
            if saved_file_count >= max_saved_files:
                print(f"Reached target file count ({max_saved_files}), stopping further processing.")
                break
                
            xml_page_url = result.xml_page_link
            print(f"\n--- Processing result: {result.file_name} from {xml_page_url} ---")
            
            # Find download link
            download_url = await find_download_link(xml_page_url)
            if not download_url:
                errors.append(f"No download link found for {result.file_name} ({xml_page_url})")
                continue
                
            # Download and process subtitle
            processed_files, new_errors, downloads = await download_and_process_subtitle(
                download_url,
                dest_dir,
                result,
                existing_filenames_in_db,
                imdb_id,
                db
            )
            
            # Update tracking variables
            all_processed_files.extend(processed_files)
            errors.extend(new_errors)
            successful_downloads += downloads
            saved_file_count += len(processed_files)
            
            # Update existing filenames set with newly saved files
            for file_path in processed_files:
                existing_filenames_in_db.add(Path(file_path).name)
                
            # Check if we've reached the limit
            if saved_file_count >= max_saved_files:
                print(f"Reached target file count ({max_saved_files}), stopping further processing.")
                break

        # --- Final Status Update ---
        final_status = "failure"  # Default to failure
        final_message = f"Processing complete for {imdb_id}."
        newly_saved_count = saved_file_count - existing_count

        if saved_file_count >= max_saved_files:
            final_status = "success"
            final_message += f" Reached or exceeded limit ({limit}). Total files: {saved_file_count}."
            if newly_saved_count > 0:
                final_message += f" Saved {newly_saved_count} new file(s)."
        elif newly_saved_count > 0:  # Saved some new files but didn't reach limit
            final_status = "success"  # Consider success if *any* new file was saved
            final_message += f" Saved {newly_saved_count} new file(s). Total files: {saved_file_count} (limit: {limit})."
        elif existing_count > 0 and newly_saved_count == 0:  # No new files saved, but some existed initially
            final_status = "success"  # Success because files exist
            final_message += f" No new files saved. Total files remain {saved_file_count}."
        elif not all_processed_files and not errors:  # No files found/saved and no processing errors
            final_message += " No suitable subtitle files found or saved."
            # Keep status as failure
        elif errors:
            final_message += f" Encountered {len(errors)} error(s): {'; '.join(errors[:3])}{'...' if len(errors) > 3 else ''}"
            # Keep status as failure if errors occurred, even if some files were saved

        # --- Update Final Search Log Status ---
        search_log_entry.message = final_message
        
        print(f"Final status for {imdb_id}: {final_status}. Message: {final_message}")

        return SrtDownloadStatus(
            status=final_status,
            message=final_message,
            processed_files=sorted(list(set(all_processed_files))),  # Return unique list of all relevant files
        )
        
    except Exception as e:
        error_message = f"An unexpected error occurred: {str(e)}"
        print(error_message)
        traceback.print_exc()
        search_log_entry.message = error_message
        return SrtDownloadStatus(status="failure", message=error_message)

# Helper function to verify movie exists
async def verify_movie_exists(imdb_id: str, db: AsyncSession):
    """
    Verify that a movie with the given IMDB ID exists in the database.
    Raises an HTTPException if the movie is not found.
    """
    movie_exists = await db.execute(
        select(TitleBasics.tconst).where(TitleBasics.tconst == imdb_id)
    )
    if movie_exists.scalar_one_or_none() is None:
        raise HTTPException(
            status_code=404, detail=f"Movie with IMDB ID '{imdb_id}' not found"
        )

# Helper function to get subtitles from database
async def get_subtitles_from_db(imdb_id: str, db: AsyncSession) -> List[SubtitleFile]:
    """
    Get all subtitle files for a movie from the database.
    """
    query = select(SubtitleFile).where(SubtitleFile.imdb_id == imdb_id)
    result = await db.execute(query)
    return result.scalars().all()

# Helper function to convert SubtitleFile objects to SubtitleInfo objects
def convert_to_subtitle_info(subtitle_files: List[SubtitleFile]) -> List[SubtitleInfo]:
    """
    Convert a list of SubtitleFile objects to a list of SubtitleInfo objects.
    """
    subtitles = []
    for subtitle in subtitle_files:
        # Get language from the database
        language = subtitle.language
        
        # Get human-readable language name
        display_language = get_language_display_name(language)
        
        # Create URL for downloading
        url = f"/subtitles/download/{subtitle.id}"
        
        # Get filename from path
        filename = os.path.basename(subtitle.filename)
        
        # Convert binary hash to hex string for API response
        file_hash_hex = subtitle.file_hash.hex() if subtitle.file_hash else None
        
        subtitles.append(
            SubtitleInfo(
                language=display_language,
                url=url,
                filename=subtitle.filename,
                is_default_cn=subtitle.is_default_cn,
                is_default_en=subtitle.is_default_en,
                shooter_title=subtitle.shooter_title,
                file_hash_hex=file_hash_hex
            )
        )
    
    return subtitles

@subtitles_router.get("/db/{imdb_id}", response_model=List[SubtitleInfo])
async def get_movie_subtitles_from_db(
    imdb_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    """
    Get all available subtitles for a movie by its IMDB ID from the database only.
    
    This endpoint only returns subtitles that are already in the database and does not
    attempt to fetch new subtitles from external sources like assrt.net.
    
    Use this endpoint when you want to quickly check what subtitles are available
    without triggering any external API calls or downloads.
    """
    # First verify the movie exists
    await verify_movie_exists(imdb_id, db)
    
    # Get all subtitle files for this movie from the database
    subtitle_files = await get_subtitles_from_db(imdb_id, db)
    
    if not subtitle_files:
        return []
    
    # Convert to SubtitleInfo objects
    return convert_to_subtitle_info(subtitle_files)

@subtitles_router.get("/fetch/{imdb_id}", response_model=List[SubtitleInfo])
async def get_movie_subtitles(
    imdb_id: str,
    limit: int = Query(5, description="Maximum number of subtitle files to fetch.", ge=1),
    db: AsyncSession = Depends(get_db_session)
):
    """
    Get all available subtitles for a movie by its IMDB ID, fetching from external sources if needed.
    
    This endpoint first checks the database for existing subtitles. If fewer than the requested
    limit are found, it will search assrt.net and download additional subtitles to meet the limit.
    
    Use this endpoint when you want to ensure you have the maximum number of subtitles available,
    even if it requires external API calls and downloads.
    """
    # First verify the movie exists
    await verify_movie_exists(imdb_id, db)
    
    # Get all subtitle files for this movie from the database
    subtitle_files = await get_subtitles_from_db(imdb_id, db)
    
    # Check if we need to fetch more subtitles
    if len(subtitle_files) < limit:
        print(f"Found {len(subtitle_files)} subtitles in database, which is less than the limit ({limit}). Fetching more from assrt.net.")
        
        # Call the search_and_download_subtitles function to fetch more subtitles
        download_result = await search_and_download_subtitles(imdb_id=imdb_id, limit=limit, db=db)
        
        # If new subtitles were downloaded, refresh the subtitle_files list
        if download_result.status == "success" and download_result.processed_files:
            # Re-query the database to get the updated list of subtitles
            subtitle_files = await get_subtitles_from_db(imdb_id, db)
    
    if not subtitle_files:
        return []
    
    # Convert to SubtitleInfo objects
    return convert_to_subtitle_info(subtitle_files)


@subtitles_router.get("/download/{subtitle_id}")
async def download_subtitle(
    subtitle_id: int,
    db: AsyncSession = Depends(get_db_session)
):
    """
    Download a specific subtitle file by its ID.
    Handles encoding issues to prevent special character corruption.
    """
    # Get the subtitle file record
    query = select(SubtitleFile).where(SubtitleFile.id == subtitle_id)
    result = await db.execute(query)
    subtitle = result.scalar_one_or_none()
    
    if subtitle is None:
        raise HTTPException(
            status_code=404, detail=f"Subtitle with ID {subtitle_id} not found"
        )
    
    # Get the file path
    filename = subtitle.filename
    
    # Construct the full path by joining SRT_SAVE_DIR with the filename
    full_path = os.path.join(SRT_SAVE_DIR, subtitle.imdb_id, filename)
    
    # Check if file exists
    if not os.path.exists(full_path):
        raise HTTPException(
            status_code=404, detail=f"Subtitle file not found on disk"
        )
    
    # Try to detect encoding and fix potential encoding issues
    try:
        # First try to read as UTF-8
        with open(full_path, "r", encoding="utf-8") as f:
            text_content = f.read()
            
        # If we get here, UTF-8 reading was successful
        content = text_content.encode("utf-8")
    except UnicodeDecodeError:
        # If UTF-8 fails, try to detect encoding
        try:
            import chardet
            # Read the raw bytes
            with open(full_path, "rb") as f:
                raw_content = f.read()
            
            # Detect encoding
            detection = chardet.detect(raw_content)
            detected_encoding = detection["encoding"]
            confidence = detection["confidence"]
            
            print(f"Detected encoding: {detected_encoding} with confidence: {confidence}")
            
            if detected_encoding and confidence > 0.7:
                # Try to decode with detected encoding and re-encode as UTF-8
                text_content = raw_content.decode(detected_encoding, errors="replace")
                content = text_content.encode("utf-8")
            else:
                # If detection fails or has low confidence, use raw content
                content = raw_content
        except ImportError:
            # If chardet is not available, fall back to binary read
            with open(full_path, "rb") as f:
                content = f.read()
        except Exception as e:
            print(f"Error handling encoding: {str(e)}")
            # Fall back to binary read
            with open(full_path, "rb") as f:
                content = f.read()
    
    # Determine content type based on file extension
    content_type = "application/octet-stream"  # Default
    if filename.endswith(".srt"):
        content_type = "application/x-subrip; charset=utf-8"
    elif filename.endswith(".ass"):
        content_type = "text/plain; charset=utf-8"
    
    # Get filename from path
    file_basename = os.path.basename(filename)
    
    # Update query count for analytics
    subtitle.query_count += 1
    await db.commit()
    
    # Return the file as a response
    return Response(
        content=content,
        media_type=content_type,
        headers={"Content-Disposition": f'attachment; filename="{file_basename}"'}
    )

@subtitles_router.delete("/cleanup/{imdb_id}")
async def cleanup_movie_subtitles(
    imdb_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    """
    Clean up subtitle data for a specific movie by its IMDB ID.
    
    This endpoint:
    1. Gets all subtitle files for the given IMDB ID from subtitle_file table
    2. For each file, checks if it exists in the subtitle_duplicate table
    3. Only deletes files that don't exist in the subtitle_duplicate table
    4. Deletes all records from the subtitle_file table for the IMDB ID
    
    Use with caution as this operation cannot be undone.
    """
    # First verify the movie exists
    await verify_movie_exists(imdb_id, db)
    
    # Get all subtitle files for this movie from the database
    subtitle_files = await get_subtitles_from_db(imdb_id, db)
    
    if not subtitle_files:
        return {"status": "success", "message": f"No subtitle files found for IMDB ID {imdb_id}"}
    
    try:
        # First, check if this IMDB ID exists as duplicate_imdb_id in subtitle_duplicate table
        # If found, delete those rows from DB, but do not delete files from disk
        check_duplicate_imdb_stmt = text("""
            SELECT COUNT(*) FROM media.subtitle_duplicate
            WHERE duplicate_imdb_id = :imdb_id
        """)
        result = await db.execute(check_duplicate_imdb_stmt, {"imdb_id": imdb_id})
        duplicate_count = result.scalar_one()
        
        if duplicate_count > 0:
            # Delete rows where this IMDB ID is the duplicate_imdb_id
            delete_duplicate_stmt = text("""
                DELETE FROM media.subtitle_duplicate
                WHERE duplicate_imdb_id = :imdb_id
            """)
            await db.execute(delete_duplicate_stmt, {"imdb_id": imdb_id})
            print(f"Deleted {duplicate_count} rows from subtitle_duplicate table where duplicate_imdb_id = {imdb_id}")
        
        # For each subtitle file, check if it exists in subtitle_duplicate table
        files_to_delete = []
        files_to_keep = []
        subtitle_ids_to_delete = []
        
        for subtitle in subtitle_files:
            # Check if this file exists in subtitle_duplicate table
            # Either as original or duplicate
            check_duplicate_stmt = text("""
                SELECT 1 FROM media.subtitle_duplicate
                WHERE (original_imdb_id = :imdb_id AND original_filename = :filename)
                OR (duplicate_imdb_id = :imdb_id AND duplicate_filename = :filename)
                LIMIT 1
            """)
            result = await db.execute(
                check_duplicate_stmt,
                {"imdb_id": imdb_id, "filename": os.path.basename(subtitle.filename)}
            )
            
            if result.scalar_one_or_none() is None:
                # File doesn't exist in subtitle_duplicate, so we can delete it
                file_path = os.path.join(SRT_SAVE_DIR, imdb_id, os.path.basename(subtitle.filename))
                files_to_delete.append(file_path)
                subtitle_ids_to_delete.append(subtitle.id)
            else:
                # File exists in subtitle_duplicate, so we keep it
                files_to_keep.append(os.path.basename(subtitle.filename))
        
        # Delete the files that don't exist in subtitle_duplicate
        deleted_count = 0
        for file_path in files_to_delete:
            if os.path.exists(file_path):
                try:
                    os.remove(file_path)
                    deleted_count += 1
                    print(f"Deleted file: {file_path}")
                except Exception as e:
                    print(f"Error deleting file {file_path}: {str(e)}")
        
        # Delete only the specific subtitle_file records that don't exist in subtitle_duplicate
        if subtitle_ids_to_delete:
            # Convert list of IDs to a comma-separated string for the IN clause
            ids_str = ','.join(str(id) for id in subtitle_ids_to_delete)
            delete_file_stmt = text(
                f"DELETE FROM media.subtitle_file WHERE id IN ({ids_str})"
            )
            await db.execute(delete_file_stmt)
        
        # Commit the database changes
        await db.commit()
        
        # Check if the directory is now empty and can be removed
        subtitle_dir = os.path.join(SRT_SAVE_DIR, imdb_id)
        if os.path.exists(subtitle_dir) and not os.listdir(subtitle_dir):
            try:
                os.rmdir(subtitle_dir)
                print(f"Removed empty subtitle directory: {subtitle_dir}")
            except Exception as e:
                print(f"Error removing empty subtitle directory {subtitle_dir}: {str(e)}")
        
        return {
            "status": "success",
            "message": f"Successfully processed {len(subtitle_files)} subtitle files for IMDB ID {imdb_id}",
            "deleted_files": deleted_count,
            "kept_files": len(files_to_keep),
            "kept_filenames": files_to_keep,
            "deleted_duplicate_rows": duplicate_count
        }
    
    except Exception as e:
        # Rollback in case of error
        await db.rollback()
        error_message = f"Error cleaning up subtitles for IMDB ID {imdb_id}: {str(e)}"
        print(error_message)
        traceback.print_exc()
        return {"status": "error", "message": error_message}