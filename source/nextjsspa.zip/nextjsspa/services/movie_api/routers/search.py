from fastapi import APIRouter, Query, HTTPException, Depends
from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import or_, and_, desc

# Import schemas
from ..schemas import MovieSearchResult, NameBasicInfo, MovieWithRating

# Import database session and models
from packages.db.database import get_db_session
from packages.models.imdb import TitleBasics, NameBasics, TitlePrincipals, TitleRatings

search_router = APIRouter(prefix="/search", tags=["Search"])

@search_router.get("/movies", response_model=List[MovieWithRating])
async def search_movies(
    query: str = Query(..., description="Search keyword for movie title"),
    year: Optional[int] = Query(None, description="Filter by release year"),
    limit: int = Query(20, description="Maximum number of results to return", ge=1, le=100),
    db: AsyncSession = Depends(get_db_session),
):
    """
    Search for movies by title keyword. Matches partial words.
    Optionally filter by release year.
    """
    if not query:
        raise HTTPException(status_code=400, detail="Search query cannot be empty")

    search_term = query.strip()
    
    # First, build a query to get all matching movies
    base_query = select(
        TitleBasics,
        TitleRatings.average_rating,
        TitleRatings.num_votes
    ).outerjoin(
        TitleRatings, TitleBasics.tconst == TitleRatings.tconst
    )

    # --- Conditions ---
    conditions = []

    # 1. Match Title (Partial Word Matching)
    if search_term:
        search_parts = search_term.split()
        title_conditions = []
        for part in search_parts:
            part_condition = or_(
                TitleBasics.primary_title.ilike(f"%{part}%"),
                TitleBasics.original_title.ilike(f"%{part}%"),
            )
            title_conditions.append(part_condition)
        if title_conditions:
            conditions.append(and_(*title_conditions))  # All parts must match

    # Apply combined conditions
    if conditions:
        base_query = base_query.where(and_(*conditions))

    # 2. Filter by Year (if provided)
    if year is not None:
        base_query = base_query.where(TitleBasics.start_year == year)
        
    # Create a query that orders the results as desired
    ordered_query = base_query.order_by(
        TitleRatings.average_rating.desc().nullslast(),  # NULL ratings at the end
        TitleRatings.num_votes.desc().nullslast(),       # Then by vote count (high to low)
        TitleBasics.start_year.desc().nullslast(),       # Then by year
        TitleBasics.primary_title,                       # Then by title
    ).limit(limit)

    # Execute query
    result = await db.execute(ordered_query)
    rows = result.all()

    # Format results
    movies_result = []
    for row in rows:
        movie, avg_rating, num_votes = row
        
        # Create a dictionary with all movie attributes
        movie_dict = {
            "tconst": movie.tconst,
            "title_type": movie.title_type,
            "primary_title": movie.primary_title,
            "original_title": movie.original_title,
            "is_adult": movie.is_adult,
            "start_year": movie.start_year,
            "end_year": movie.end_year,
            "runtime_minutes": movie.runtime_minutes,
            "genres": movie.genres,
            
            # Add rating information
            "average_rating": avg_rating,
            "num_votes": num_votes
        }
        
        movies_result.append(MovieWithRating(**movie_dict))

    return movies_result

@search_router.get("/people", response_model=List[NameBasicInfo])
async def search_people(
    query: str = Query(..., description="Search keyword for person's name"),
    limit: int = Query(20, description="Maximum number of results to return", ge=1, le=100),
    db: AsyncSession = Depends(get_db_session),
):
    """
    Search for people by name.
    """
    if not query:
        raise HTTPException(status_code=400, detail="Search query cannot be empty")

    search_term = query.strip()
    
    # Build the query
    query = select(NameBasics).where(
        NameBasics.primary_name.ilike(f"%{search_term}%")
    ).limit(limit)
    
    # Execute query
    result = await db.execute(query)
    people = result.scalars().all()
    
    return list(people)

@search_router.get("/movies-by-person", response_model=List[MovieSearchResult])
async def search_movies_by_person(
    query: str = Query(..., description="Search keyword for person's name"),
    category: Optional[str] = Query(None, description="Filter by category (e.g., 'actor', 'director')"),
    limit: int = Query(20, description="Maximum number of results to return", ge=1, le=100),
    db: AsyncSession = Depends(get_db_session),
):
    """
    Search for movies associated with a person (actor, actress, director, writer, producer)
    by matching their name.
    """
    if not query:
        raise HTTPException(status_code=400, detail="Search query cannot be empty")

    search_term = query.strip()
    
    # 1. Find nconst of people matching the name query
    name_subquery = (
        select(NameBasics.nconst)
        .where(NameBasics.primary_name.ilike(f"%{search_term}%"))
        .subquery()
    )

    # 2. Find tconst of titles where these people have a relevant role
    principals_subquery = (
        select(TitlePrincipals.tconst)
        .where(TitlePrincipals.nconst.in_(select(name_subquery.c.nconst)))
    )
    
    # Apply category filter if provided
    if category:
        principals_subquery = principals_subquery.where(TitlePrincipals.category == category)
    
    principals_subquery = principals_subquery.distinct().subquery()

    # 3. Select movie details for those tconsts
    base_query = (
        select(
            TitleBasics,
            TitleRatings.average_rating,
            TitleRatings.num_votes
        )
        .outerjoin(TitleRatings, TitleBasics.tconst == TitleRatings.tconst)
        .where(TitleBasics.tconst.in_(select(principals_subquery.c.tconst)))
    )

    # Create a query that orders the results as desired
    ordered_query = base_query.order_by(
        TitleRatings.num_votes.desc().nullslast(),       # Then by vote count (high to low)
        # TitleRatings.average_rating.desc().nullslast(),  # NULL ratings at the end
        TitleBasics.start_year.desc().nullslast(),       # Then by year
        # TitleBasics.primary_title,                       # Then by title
    ).limit(limit)

    # Execute query
    result = await db.execute(ordered_query)
    rows = result.all()

    # Format results
    movies_result = []
    for row in rows:
        movie, avg_rating, num_votes = row
        
        # Create a dictionary with all movie attributes
        movie_dict = {
            "tconst": movie.tconst,
            "title_type": movie.title_type,
            "primary_title": movie.primary_title,
            "original_title": movie.original_title,
            "is_adult": movie.is_adult,
            "start_year": movie.start_year,
            "end_year": movie.end_year,
            "runtime_minutes": movie.runtime_minutes,
            "genres": movie.genres,
            
            # Add rating information
            "average_rating": avg_rating,
            "num_votes": num_votes
        }
        
        movies_result.append(MovieWithRating(**movie_dict))

    return movies_result

# No subtitle-related endpoints here