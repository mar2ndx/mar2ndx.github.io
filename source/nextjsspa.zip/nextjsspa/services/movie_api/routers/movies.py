from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import joinedload
from typing import List, Optional

from packages.db.database import get_db_session
from packages.models.imdb import TitleBasics, TitleRatings, TitlePrincipals, NameBasics
from ..schemas import (
    TitleBasicInfo,
    TitleRatingInfo,
    TitlePrincipalInfo,
    EnrichedTitlePrincipalInfo,
    MovieSearchResult
)

import json

movies_router = APIRouter(prefix="/movies", tags=["Movies"])

@movies_router.get("/id/{imdb_id}", response_model=TitleBasicInfo)
async def get_movie(imdb_id: str, db: AsyncSession = Depends(get_db_session)):
    """
    Get detailed information about a movie by its IMDB ID (tconst).
    """
    result = await db.execute(select(TitleBasics).where(TitleBasics.tconst == imdb_id))
    movie = result.scalar_one_or_none()
    
    if movie is None:
        raise HTTPException(
            status_code=404, detail=f"Movie with IMDB ID '{imdb_id}' not found"
        )
    
    return movie

@movies_router.get("/id/{imdb_id}/ratings", response_model=TitleRatingInfo)
async def get_movie_ratings(imdb_id: str, db: AsyncSession = Depends(get_db_session)):
    """
    Get rating information for a movie by its IMDB ID (tconst).
    """
    # First verify the movie exists
    movie_exists = await db.execute(
        select(TitleBasics.tconst).where(TitleBasics.tconst == imdb_id)
    )
    if movie_exists.scalar_one_or_none() is None:
        raise HTTPException(
            status_code=404, detail=f"Movie with IMDB ID '{imdb_id}' not found"
        )
    
    # Get the ratings
    result = await db.execute(select(TitleRatings).where(TitleRatings.tconst == imdb_id))
    ratings = result.scalar_one_or_none()
    
    if ratings is None:
        # Return default ratings object if no ratings found
        return TitleRatingInfo(tconst=imdb_id, average_rating=None, num_votes=0)
    
    return ratings

@movies_router.get("/id/{imdb_id}/credits", response_model=List[EnrichedTitlePrincipalInfo])
async def get_movie_credits(
    imdb_id: str,
    category: Optional[str] = None,
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db_session)
):
    """
    Get enriched cast and crew information for a movie by its IMDB ID (tconst).
    Includes detailed person information along with their role in the movie.
    Optionally filter by category (e.g., "actor", "director").
    """
    # First verify the movie exists
    movie_exists = await db.execute(
        select(TitleBasics.tconst).where(TitleBasics.tconst == imdb_id)
    )
    if movie_exists.scalar_one_or_none() is None:
        raise HTTPException(
            status_code=404, detail=f"Movie with IMDB ID '{imdb_id}' not found"
        )
    
    # Build the query to join TitlePrincipals with NameBasics
    query = (
        select(TitlePrincipals, NameBasics)
        .join(NameBasics, TitlePrincipals.nconst == NameBasics.nconst, isouter=True)
        .where(TitlePrincipals.tconst == imdb_id)
    )
    
    # Apply category filter if provided
    if category:
        query = query.where(TitlePrincipals.category == category)
    
    # Add ordering and limit
    query = query.order_by(TitlePrincipals.ordering).limit(limit)
    
    # Execute query
    result = await db.execute(query)
    credits_with_people = result.all()
    
    response = []
    for credit, person in credits_with_people:
        # Create a combined dictionary with credit and person data
        combined_data = credit.__dict__.copy()
        
        # Parse characters JSON if it exists
        if combined_data["characters"]:
            combined_data["characters"] = json.loads(combined_data["characters"])
        
        # Add person data if available
        if person:
            combined_data["primary_name"] = person.primary_name
            combined_data["birth_year"] = person.birth_year
            combined_data["death_year"] = person.death_year
            combined_data["primary_profession"] = person.primary_profession
            combined_data["known_for_titles"] = person.known_for_titles
        
        response.append(EnrichedTitlePrincipalInfo(**combined_data))

    return response