# Movie API Design

## Base URL

```
http://localhost:8001
```

## API Endpoints

### Movies

#### Get Movie by IMDB ID

```
GET /movies/{imdb_id}
```

Retrieves detailed information about a movie by its IMDB ID (tconst).

**Path Parameters:**
- `imdb_id` (string, required): The IMDB ID (tconst) of the movie

**Response:**
- `200 OK`: Returns the movie details
- `404 Not Found`: Movie not found

**Response Schema:** `TitleBasicInfo`

#### Get Movie Ratings

```
GET /movies/{imdb_id}/ratings
```

Retrieves rating information for a movie.

**Path Parameters:**
- `imdb_id` (string, required): The IMDB ID (tconst) of the movie

**Response:**
- `200 OK`: Returns the movie ratings
- `404 Not Found`: Movie not found

**Response Schema:** `TitleRatingInfo`

#### Get Movie Cast and Crew

```
GET /movies/{imdb_id}/credits
```

Retrieves the cast and crew information for a movie.

**Path Parameters:**
- `imdb_id` (string, required): The IMDB ID (tconst) of the movie

**Query Parameters:**
- `category` (string, optional): Filter by category (e.g., "actor", "director")
- `limit` (integer, optional, default=20): Maximum number of results to return

**Response:**
- `200 OK`: Returns the cast and crew information
- `404 Not Found`: Movie not found

**Response Schema:** List of `TitlePrincipalInfo`

### People

#### Get Person by IMDB ID

```
GET /people/{nconst}
```

Retrieves detailed information about a person by their IMDB ID (nconst).

**Path Parameters:**
- `nconst` (string, required): The IMDB ID (nconst) of the person

**Response:**
- `200 OK`: Returns the person details
- `404 Not Found`: Person not found

**Response Schema:** `NameBasicInfo`

#### Get Person's Filmography

```
GET /people/{nconst}/filmography
```

Retrieves the filmography for a person.

**Path Parameters:**
- `nconst` (string, required): The IMDB ID (nconst) of the person

**Query Parameters:**
- `category` (string, optional): Filter by category (e.g., "actor", "director")
- `limit` (integer, optional, default=20): Maximum number of results to return
- `sort` (string, optional, default="year_desc"): Sort order ("year_asc", "year_desc")

**Response:**
- `200 OK`: Returns the person's filmography
- `404 Not Found`: Person not found

**Response Schema:** List of `MovieSearchResult`

### Subtitles

#### Get Subtitles for Movie

```
GET /subtitles/{imdb_id}
```

Retrieves all available subtitles for a movie. First fetches subtitles from the database, and if not found or fewer than requested, searches and downloads from assrt.net.

**Path Parameters:**
- `imdb_id` (string, required): The IMDB ID (tconst) of the movie

**Query Parameters:**
- `limit` (integer, optional, default=5): Maximum number of subtitle files to fetch

**Response:**
- `200 OK`: Returns the available subtitles
- `404 Not Found`: Movie not found or no subtitles available

**Response Schema:** List of `SubtitleInfo`

#### Download Subtitle

```
GET /subtitles/download/{subtitle_id}
```

Downloads a specific subtitle file.

**Path Parameters:**
- `subtitle_id` (string, required): The ID of the subtitle file

**Response:**
- `200 OK`: Returns the subtitle file
- `404 Not Found`: Subtitle not found

**Response Type:** File download

### Search

#### Search Movies by Title

```
GET /search/movies
```

Searches for movies by title keyword.

**Query Parameters:**
- `query` (string, required): Search keyword for movie title
- `year` (integer, optional): Filter by release year
- `limit` (integer, optional, default=20): Maximum number of results to return

**Response:**
- `200 OK`: Returns the search results
- `400 Bad Request`: Invalid parameters

**Response Schema:** List of `MovieSearchResult`

#### Search People by Name

```
GET /search/people
```

Searches for people by name.

**Query Parameters:**
- `query` (string, required): Search keyword for person's name
- `limit` (integer, optional, default=20): Maximum number of results to return

**Response:**
- `200 OK`: Returns the search results
- `400 Bad Request`: Invalid parameters

**Response Schema:** List of `NameBasicInfo`

#### Search Movies by Person

```
GET /search/movies-by-person
```

Searches for movies associated with a person.

**Query Parameters:**
- `query` (string, required): Search keyword for person's name
- `category` (string, optional): Filter by category (e.g., "actor", "director")
- `limit` (integer, optional, default=20): Maximum number of results to return

**Response:**
- `200 OK`: Returns the search results
- `400 Bad Request`: Invalid parameters

**Response Schema:** List of `MovieSearchResult`

## Data Models

### MovieSearchResult

```json
{
  "tconst": "string",
  "primary_title": "string",
  "original_title": "string",
  "start_year": "integer (optional)",
  "subtitles": [
    {
      "language": "string",
      "url": "string"
    }
  ]
}
```

### TitleBasicInfo

```json
{
  "tconst": "string",
  "title_type": "string",
  "primary_title": "string",
  "original_title": "string",
  "is_adult": "boolean (optional)",
  "start_year": "integer (optional)",
  "end_year": "integer (optional)",
  "runtime_minutes": "integer (optional)",
  "genres": ["string (optional)"]
}
```

### TitleRatingInfo

```json
{
  "tconst": "string",
  "average_rating": "float (optional)",
  "num_votes": "integer"
}
```

### TitlePrincipalInfo

```json
{
  "tconst": "string",
  "ordering": "integer",
  "nconst": "string (optional)",
  "category": "string",
  "job": "string (optional)",
  "characters": ["string (optional)"]
}
```

### NameBasicInfo

```json
{
  "nconst": "string",
  "primary_name": "string",
  "birth_year": "integer (optional)",
  "death_year": "integer (optional)",
  "primary_profession": ["string (optional)"],
  "known_for_titles": ["string (optional)"]
}
```

### SubtitleInfo

```json
{
  "language": "string",
  "url": "string"
}
```

### SrtSearchResult

```json
{
  "source": "string",
  "file_name": "string",
  "xml_page_link": "string (optional)"
}
```

### SrtDownloadStatus

```json
{
  "status": "string",
  "message": "string",
  "processed_files": ["string"]
}