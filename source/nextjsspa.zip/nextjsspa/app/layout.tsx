import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { LeftNavigation } from "@/components/left-navigation"
import { ThemeProvider } from "@/components/theme-provider"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "SPA - Subtitle Processing Application",
  description: "Process, analyze, and manage subtitle files",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <div className="flex min-h-screen">
            <LeftNavigation />
            <main className="flex-1 pl-16 md:pl-64">{children}</main>
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}
