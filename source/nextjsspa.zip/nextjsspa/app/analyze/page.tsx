export default function AnalyzePage() {
  return (
    <div className="container py-8">
      <div className="mx-auto max-w-3xl space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Subtitle Analysis</h1>
          <p className="text-muted-foreground">Analyze subtitle content and quality</p>
        </div>
        <div className="rounded-lg border border-dashed p-8 text-center">
          <h3 className="text-lg font-semibold">Analysis Feature Coming Soon</h3>
          <p className="mt-2 text-sm text-muted-foreground">This feature is currently under development.</p>
        </div>
      </div>
    </div>
  )
}
