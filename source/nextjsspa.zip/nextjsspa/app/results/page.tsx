import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { MovieResults } from "@/components/movie-results"

export default function ResultsPage() {
  return (
    <div className="container py-8">
      <div className="mb-8">
        <Button variant="ghost" asChild>
          <Link href="/" className="flex items-center">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Search
          </Link>
        </Button>
      </div>

      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Movie Search Results</h1>
          <p className="text-muted-foreground">Showing all available movies</p>
        </div>

        <MovieResults />
      </div>
    </div>
  )
}
