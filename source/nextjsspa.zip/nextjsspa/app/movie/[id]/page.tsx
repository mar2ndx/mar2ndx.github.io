import Image from "next/image"
import { notFound } from "next/navigation"
import { Star, ExternalLink, Film } from "lucide-react" // Import ExternalLink and Film for placeholder
import Link from "next/link" // Import Link for consistency, though <a> is fine for external

import { SubtitleHandler } from "@/components/subtitle-handler" // Updated import
import { Badge } from "@/components/ui/badge"
import { findByExternalId, getTmdbImageUrl } from "@/lib/tmdb-service" // Import TMDb functions

// Define the structure of the API responses
interface MovieData {
  tconst: string
  title_type: string
  primary_title: string
  original_title: string
  is_adult: boolean
  start_year: number
  end_year: number | null
  runtime_minutes: number
  genres: string[]
}

interface MovieRating {
  tconst: string
  average_rating: number
  num_votes: number
}

// Updated interface based on enriched API response
interface MovieCredit {
  tconst: string; // Assuming this is still relevant, though not in the example? Or maybe it's the movie's tconst? Let's keep it for now.
  ordering: number;
  nconst: string; // Unique identifier for the person
  category: string; // e.g., 'actress', 'director', 'writer'
  job: string | null; // Specific job for crew members
  characters: string[] | null; // Character names for actors
  primary_name: string; // The person's name
  birth_year: number | null;
  death_year: number | null;
  primary_profession: string[] | null;
  known_for_titles: string[] | null;
}

async function getMovieData(id: string): Promise<MovieData | null> {
  try {
    const response = await fetch(`http://localhost:8001/movies/id/${id}`, { cache: 'no-store' })
    if (!response.ok) {
      if (response.status === 404) return null
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    return await response.json()
  } catch (error) {
    console.error("Failed to fetch movie data:", error)
    return null
  }
}

async function getMovieRating(id: string): Promise<MovieRating | null> {
  try {
    const response = await fetch(`http://localhost:8001/movies/id/${id}/ratings`, { cache: 'no-store' })
    if (!response.ok) {
      // Don't throw 404, just return null if no rating found
      if (response.status === 404) return null
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    return await response.json()
  } catch (error) {
    console.error("Failed to fetch movie rating:", error)
    return null
  }
}

async function getMovieCredits(id: string): Promise<MovieCredit[] | null> {
  try {
    // Fetching more credits to ensure we get key roles
    const response = await fetch(`http://localhost:8001/movies/id/${id}/credits?limit=30`, { cache: 'no-store' })
    if (!response.ok) {
      if (response.status === 404) return null
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    return await response.json()
  } catch (error) {
    console.error("Failed to fetch movie credits:", error)
    return null
  }
}

// Helper to format large numbers
const formatVotes = (num: number): string => {
  if (num >= 1_000_000) {
    return (num / 1_000_000).toFixed(1) + 'M';
  }
  if (num >= 1_000) {
    return (num / 1_000).toFixed(0) + 'K';
  }
  return num.toString();
};


export default async function MoviePage({ params }: { params: { id: string } }) {
  // const { id } = params; // Access params.id directly below

  // Fetch local data first
  const movie = await getMovieData(params.id);

  if (!movie) {
    notFound() // Trigger 404 page if core movie data fetch fails
  }

  // Fetch remaining local data and TMDb data in parallel
  const [rating, credits, tmdbMovie] = await Promise.all([
    getMovieRating(params.id),
    getMovieCredits(params.id),
    findByExternalId(movie.tconst) // Fetch TMDb data using IMDb ID
  ]);

  // Construct poster URL
  const posterUrl = tmdbMovie ? getTmdbImageUrl(tmdbMovie.poster_path, 'w500') : null;

  // Filter credits for display
  const director = credits?.find(c => c.category === 'director');
  const writers = credits?.filter(c => c.category === 'writer') || [];
  const actors = credits?.filter(c => c.category === 'actor' || c.category === 'actress').slice(0, 10) || []; // Limit actors displayed

  // Names are now available directly in the credits object via primary_name

  return (
    <div className="container py-8">
      <div className="space-y-8 p-4">
        <div className="flex flex-col gap-6 md:flex-row">
          <div className="shrink-0">
            <div className="relative aspect-[2/3] w-40 overflow-hidden rounded-lg md:w-48 bg-muted/30 border">
              {posterUrl ? (
                <Image
                  src={posterUrl}
                  alt={`${movie.primary_title} poster`}
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 160px, 192px"
                  priority // Load poster quickly
                />
              ) : (
                // Simple placeholder if no poster found
                <div className="flex h-full w-full items-center justify-center bg-secondary text-muted-foreground">
                  <Film className="h-12 w-12" />
                </div>
              )}
            </div>
          </div>
          <div className="flex-1 space-y-3">
            <div className="flex items-center gap-2">
              <h1 className="text-3xl font-bold tracking-tight">
                {movie.primary_title} ({movie.start_year})
              </h1>
              <a
                href={`https://www.imdb.com/title/${movie.tconst}`}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={`View ${movie.primary_title} on IMDb`}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <ExternalLink className="h-5 w-5" />
              </a>
            </div>
            <div className="text-sm text-muted-foreground flex items-center gap-2 flex-wrap">
              <span>{movie.genres?.join(", ")}</span>
              {movie.runtime_minutes > 0 && <>• <span>{movie.runtime_minutes} min</span></>}
              {rating && (
                <>
                  •
                  <span className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-500" />
                    {rating.average_rating.toFixed(1)}
                    <span className="text-xs text-muted-foreground/80">({formatVotes(rating.num_votes)})</span>
                  </span>
                </>
              )}
            </div>

            {/* Credits Section */}
            <div className="space-y-2 pt-2 text-sm">
              {director && (
                <div>
                  <strong>Director:</strong>{" "}
                  <span className="inline-flex items-center gap-1">
                    {director.primary_name}
                    <a
                      href={`https://www.imdb.com/name/${director.nconst}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={`View ${director.primary_name} on IMDb`}
                      className="text-muted-foreground hover:text-foreground transition-colors"
                    >
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </span>
                </div>
              )}
              {writers.length > 0 && (
                <div>
                  <strong>Writers:</strong>{" "}
                  {writers.map((w, index) => (
                    <span key={w.nconst} className="inline-flex items-center gap-1 mr-1">
                      {w.primary_name}
                      {w.job ? ` (${w.job})` : ''}
                      <a
                        href={`https://www.imdb.com/name/${w.nconst}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        aria-label={`View ${w.primary_name} on IMDb`}
                        className="text-muted-foreground hover:text-foreground transition-colors"
                      >
                        <ExternalLink className="h-3 w-3" />
                      </a>
                      {index < writers.length - 1 ? ', ' : ''}
                    </span>
                  ))}
                </div>
              )}
               {actors.length > 0 && (
                 <div className="pt-2">
                   <h3 className="font-semibold mb-1">Cast</h3>
                   <div className="flex flex-wrap gap-2">
                     {actors.map(actor => (
                       <Badge variant="secondary" key={actor.nconst} className="inline-flex items-center gap-1.5">
                         <span>
                           {actor.primary_name}
                           {actor.characters && ` as ${actor.characters.join('/')}`}
                         </span>
                         <a
                           href={`https://www.imdb.com/name/${actor.nconst}`}
                           target="_blank"
                           rel="noopener noreferrer"
                           aria-label={`View ${actor.primary_name} on IMDb`}
                           className="text-muted-foreground hover:text-foreground transition-colors"
                         >
                           <ExternalLink className="h-3 w-3" />
                         </a>
                       </Badge>
                     ))}
                   </div>
                 </div>
               )}
            </div>

            {/* Removed the old ID link display as it's now next to the title */}
            {/* <div className="text-xs text-muted-foreground pt-4">
              ID: <a href={`https://www.imdb.com/title/${movie.tconst}`} target="_blank" rel="noopener noreferrer" className="hover:underline">{movie.tconst}</a>
            </div> */}
          </div>
        </div>

        {/* Use the new handler component */}
        {/* Pass params.id directly to the handler */}
        <SubtitleHandler movieId={params.id} />
      </div>
    </div>
  )
}
