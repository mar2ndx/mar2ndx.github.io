import { SearchForm } from "@/components/search-form"
import { RecommendedMovies } from "@/components/recommended-movies"

export default function Home() {
  return (
    <div className="container py-12">
      <div className="mx-auto max-w-3xl space-y-8 text-center mb-16">
        <div className="space-y-2">
          <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">SPA</h1>
          <p className="text-muted-foreground">Search, Parse, Analyze</p>
        </div>
        <SearchForm />
      </div>

      <div className="mx-auto max-w-6xl">
        <RecommendedMovies />
      </div>
    </div>
  )
}
