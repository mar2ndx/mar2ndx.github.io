"use client"

import type React from "react"

import { useState } from "react"
import { SubtitleParser } from "@/components/subtitle-parser"
import { mockParsedSubtitle } from "@/lib/parser-service"
import { Button } from "@/components/ui/button"
import { Upload } from "lucide-react"

export default function ParserPage() {
  const [parsedSubtitle, setParsedSubtitle] = useState(mockParsedSubtitle)

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    // In a real app, this would parse the uploaded file
    // For now, we'll just use the mock data
    console.log("File uploaded:", e.target.files?.[0]?.name)
    setParsedSubtitle(mockParsedSubtitle)
  }

  return (
    <div className="container py-8">
      <div className="mx-auto max-w-5xl space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Subtitle Parser</h1>
          <p className="text-muted-foreground">Parse, edit, and export subtitle files</p>
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h2 className="text-lg font-medium">Upload Subtitle File</h2>
            <p className="text-sm text-muted-foreground">Upload a subtitle file to parse and analyze</p>
          </div>
          <div>
            <label htmlFor="subtitle-upload">
              <Button as="span" className="cursor-pointer">
                <Upload className="mr-2 h-4 w-4" />
                Upload File
              </Button>
            </label>
            <input
              id="subtitle-upload"
              type="file"
              accept=".srt,.ass,.ssa"
              className="hidden"
              onChange={handleFileUpload}
            />
          </div>
        </div>

        {parsedSubtitle && <SubtitleParser parsedSubtitle={parsedSubtitle} />}
      </div>
    </div>
  )
}
