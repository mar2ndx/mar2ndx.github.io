import { ConfigForm } from "@/components/config-form"

export default function ConfigPage() {
  return (
    <div className="container py-8">
      <div className="mx-auto max-w-3xl space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Configuration</h1>
          <p className="text-muted-foreground">Manage your SRTracker settings</p>
        </div>
        <ConfigForm />
      </div>
    </div>
  )
}
