import { FileQuestion } from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"

export function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center rounded-lg border border-dashed p-8 text-center">
      <div className="flex h-20 w-20 items-center justify-center rounded-full bg-muted">
        <FileQuestion className="h-10 w-10 text-muted-foreground" />
      </div>
      <h3 className="mt-4 text-lg font-semibold">No subtitles found</h3>
      <p className="mt-2 text-sm text-muted-foreground">
        We couldn't find any subtitles matching your search criteria.
      </p>
      <Button asChild className="mt-4">
        <Link href="/">Try another search</Link>
      </Button>
    </div>
  )
}
