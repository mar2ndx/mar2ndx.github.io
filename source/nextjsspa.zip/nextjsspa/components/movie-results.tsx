import { mockMovies } from "@/lib/subtitle-service"
import { MovieCard } from "@/components/movie-card"

export function MovieResults() {
  // Always display all mock movies regardless of search parameters
  const movies = mockMovies

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {movies.map((movie) => (
        <MovieCard key={movie.id} movie={movie} />
      ))}
    </div>
  )
}
