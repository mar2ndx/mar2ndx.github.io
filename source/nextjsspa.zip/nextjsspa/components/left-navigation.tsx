"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Download, FileText, BarChart2, Settings } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

const navItems = [
  {
    name: "Subtitle",
    href: "/",
    icon: Download,
  },
  {
    name: "Parser",
    href: "/parser",
    icon: FileText,
  },
  {
    name: "Analyzer",
    href: "/analyze",
    icon: BarChart2,
  },
  {
    name: "Config",
    href: "/config",
    icon: Settings,
  },
]

export function LeftNavigation() {
  const pathname = usePathname()

  return (
    <div className="fixed top-0 left-0 flex h-screen w-16 flex-col border-r bg-background md:w-64">
      <div className="flex h-16 items-center border-b px-4">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <span className="hidden md:inline">SPA</span>
        </Link>
      </div>
      <nav className="flex-1 p-2">
        <ul className="space-y-2">
          {navItems.map((item) => (
            <li key={item.name}>
              <Button
                asChild
                variant="ghost"
                className={cn("w-full justify-start", pathname === item.href && "bg-muted")}
              >
                <Link href={item.href} className="flex items-center gap-3">
                  <item.icon className="h-5 w-5" />
                  <span className="hidden md:inline">{item.name}</span>
                </Link>
              </Button>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  )
}
