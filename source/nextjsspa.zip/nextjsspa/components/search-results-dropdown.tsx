"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { MovieSearchResult } from "@/lib/types" // Import the correct type
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { X, Loader2, Star, Users, Clock, Film } from "lucide-react" // Import new icons

// List of available posters
const posterImages = [
  "/images/poster/all.jpg",
  "/images/poster/amber.jpg",
  "/images/poster/babydoll.jpg",
  "/images/poster/blondie.jpg",
  "/images/poster/madam-gorski.jpg",
  "/images/poster/rocket.jpg",
  "/images/poster/sweet-pea.jpg",
]

// Helper function to get a random poster
const getRandomPoster = () => {
  return posterImages[Math.floor(Math.random() * posterImages.length)]
}

interface SearchResultsDropdownProps {
  query: string
  onClear: () => void
}

export function SearchResultsDropdown({ query, onClear }: SearchResultsDropdownProps) {
  const [results, setResults] = useState<MovieSearchResult[]>([]) // Use MovieSearchResult
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  // const [displayCount, setDisplayCount] = useState(5) // Load more might be complex with API, removing for now

  useEffect(() => {
    if (!query || query.trim().length < 2) {
      setResults([])
      setError(null)
      setIsLoading(false)
      return
    }

    const fetchResults = async () => {
      setIsLoading(true)
      setError(null)
      try {
        const response = await fetch(
          `http://localhost:8001/search/movies?query=${encodeURIComponent(query)}&limit=8` // Fetch 8 results
        )
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`)
        }
        const data: MovieSearchResult[] = await response.json() // Expect MovieSearchResult[]
        setResults(data)
      } catch (e: any) {
        console.error("Failed to fetch search results:", e)
        setError(e.message || "Failed to fetch results. Is the API running?")
        setResults([])
      } finally {
        setIsLoading(false)
      }
    }

    // Basic debounce
    const handler = setTimeout(() => {
      fetchResults()
    }, 300) // Debounce API calls by 300ms

    return () => {
      clearTimeout(handler) // Clear timeout if query changes before fetch
    }
  }, [query])

  // Removed handleLoadMore function as it's not directly applicable with API pagination yet
return (
    <Card className="absolute top-full left-0 right-0 mt-2 z-50">
      <CardContent className="p-4">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="text-sm font-medium">Search results for "{query}"</div>
            <Button variant="ghost" size="sm" onClick={onClear}>
              <X className="h-4 w-4 mr-1" />
              Clear
            </Button>
          </div>

          {isLoading && (
            <div className="flex items-center justify-center p-4">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
              <span className="ml-2 text-sm text-muted-foreground">Loading...</span>
            </div>
          )}
          {error && (
             <div className="text-center text-sm text-red-600 p-4">{error}</div>
          )}
          {!isLoading && !error && results.length === 0 && query.trim().length >= 2 && (
            <div className="text-center text-sm text-muted-foreground p-4">No results found for "{query}".</div>
          )}
          {!isLoading && !error && results.length > 0 && (
            <div className="space-y-2 max-h-60 overflow-y-auto"> {/* Added max-height and scroll */}
              {results.map((movie) => {
                const randomPoster = getRandomPoster() // Get random poster for each movie
                return (
                  <Link
                    key={movie.tconst} // Use tconst as key
                    href={`/movie/${movie.tconst}`} // Link to the movie details page
                    className="block rounded-md border p-2 hover:bg-muted" // Use block for link layout
                  >
                    <div className="flex items-center space-x-2"> {/* Use space-x-2 consistent with original */}
                      <div className="h-12 w-9 relative overflow-hidden rounded bg-muted"> {/* Added bg-muted as fallback */}
                        <Image
                          src={randomPoster} // Use random poster
                          alt={movie.primary_title}
                          fill
                          className="object-cover"
                          sizes="36px"
                          onError={(e) => {
                            // Optional: Handle image loading errors, e.g., show placeholder
                            e.currentTarget.style.display = 'none'; // Hide broken image icon
                            // Or replace src with a placeholder: e.currentTarget.src = '/placeholder.svg';
                          }}
                        />
                      </div>
                      <div className="flex-1"> {/* Allow text to wrap */}
                        <div className="font-medium">{movie.primary_title} {movie.start_year && `(${movie.start_year})`}</div>
                        <div className="text-xs text-muted-foreground space-y-0.5">
                           {/* Display Type */}
                           <div className="flex items-center">
                             <Film className="h-3 w-3 mr-1" /> {movie.title_type}
                           </div>
                           {/* Display Genres */}
                           {movie.genres && movie.genres.length > 0 && (
                             <div className="flex items-center">
                               <span className="mr-1">🎬</span> {movie.genres.join(", ")}
                             </div>
                           )}
                           {/* Display Rating and Votes */}
                           {(movie.average_rating || movie.num_votes) && (
                             <div className="flex items-center space-x-2">
                               {movie.average_rating && (
                                 <span className="flex items-center"><Star className="h-3 w-3 mr-0.5 text-yellow-500" /> {movie.average_rating.toFixed(1)}</span>
                               )}
                               {movie.num_votes && (
                                 <span className="flex items-center"><Users className="h-3 w-3 mr-0.5" /> {movie.num_votes.toLocaleString()}</span>
                               )}
                             </div>
                           )}
                           {/* Display Runtime */}
                           {movie.runtime_minutes && (
                             <div className="flex items-center">
                               <Clock className="h-3 w-3 mr-1" /> {movie.runtime_minutes} min
                             </div>
                           )}
                           {/* Display Original Title if different */}
                           {movie.original_title && movie.original_title !== movie.primary_title && (
                              <div>Original: {movie.original_title}</div>
                           )}
                           {/* Display tconst */}
                           <div>ID: {movie.tconst}</div>
                        </div>
                      </div>
                    </div>
                  </Link>
                )
              })}
            </div>
          )}
          {/* Removed Load More button */}
        </div>
      </CardContent>
    </Card>
  )
}
