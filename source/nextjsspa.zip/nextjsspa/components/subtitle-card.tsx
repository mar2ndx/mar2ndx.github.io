"use client"

import type React from "react"

import { useState } from "react"
import { Download, FileText, Star, Info, Eye } from "lucide-react"

import type { Subtitle } from "@/lib/types"
import { setAsDefault } from "@/lib/subtitle-service"
import { Button } from "@/components/ui/button"
import { Card, CardFooter, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface SubtitleCardProps {
  subtitle: Subtitle
  onSelect?: () => void
  isSelected?: boolean
  onSetAsDefault?: () => void
  availableLanguages?: string[]
  onChangeLanguage?: (language: string) => void
}

export function SubtitleCard({
  subtitle,
  onSelect,
  isSelected = false,
  onSetAsDefault,
  availableLanguages = [
    "English",
    "CN_simplified",
    "CN_traditional",
    "Japanese",
    "Korean",
    "Hindi",
    "Español",
    "Français",
    "Deutsch",
    "Italiano",
    "Português",
    "Русский",
    "Arabic",
  ],
  onChangeLanguage,
}: SubtitleCardProps) {
  const [isSettingDefault, setIsSettingDefault] = useState(false)
  const [isExtracting, setIsExtracting] = useState(false)
  const [previewContent, setPreviewContent] = useState<string | null>(null)
  const [isChangingLanguage, setIsChangingLanguage] = useState(false)

  // Function to encode URL for proper handling of special characters
  const getEncodedUrl = (url: string): string => {
    // If it's a relative URL (starts with /), prepend the base URL
    if (url.startsWith('/')) {
      // Split the URL into parts (path segments)
      const urlParts = url.split('/')
      
      // Encode each part individually to handle non-ASCII characters
      const encodedParts = urlParts.map((part) => {
        // Don't encode the empty parts (which represent the slashes)
        if (part === '') return '';
        // Encode the part to handle special characters
        return encodeURIComponent(part);
      });
      
      // Join the parts back together with slashes
      const encodedPath = encodedParts.join('/');
      
      // Prepend the base URL
      return `http://localhost:3000${encodedPath}`;
    }
    
    // Return the original URL if it's not relative
    return url;
  }

  const handleSetAsDefault = async (e: React.MouseEvent) => {
    e.stopPropagation()
    setIsSettingDefault(true)
    try {
      await setAsDefault(subtitle.id, subtitle.language)
      onSetAsDefault?.()
    } catch (error) {
      console.error("Failed to set as default:", error)
    } finally {
      setIsSettingDefault(false)
    }
  }

  const handlePreview = async (e: React.MouseEvent) => {
    e.stopPropagation()
    if (previewContent) {
      onSelect?.()
      return
    }

    setIsExtracting(true)
    try {
      // Simulate extraction delay
      await new Promise((resolve) => setTimeout(resolve, 1000))
      setPreviewContent(subtitle.preview)
      onSelect?.()
    } catch (error) {
      console.error("Failed to extract subtitle:", error)
    } finally {
      setIsExtracting(false)
    }
  }

  const handleChangeLanguage = async (language: string) => {
    setIsChangingLanguage(true)
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 500))
      onChangeLanguage?.(language)
    } catch (error) {
      console.error("Failed to change language:", error)
    } finally {
      setIsChangingLanguage(false)
    }
  }

  // Extract filename from URL
  const fileName = subtitle.url.split("/").pop() || "subtitle.rar"

  // Mock detailed subtitle info
  const detailedInfo = {
    id: `00${Math.floor(Math.random() * 100)}`,
    path: `data/srt_files/${subtitle.movieInfo.imdbId}/${fileName}`,
    "assrt-title": subtitle.name,
    "assrt-url": subtitle.url,
    timestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
  }

  return (
    <Card onClick={onSelect} className={isSelected ? "border-primary" : ""}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CardTitle className="line-clamp-1 text-base">
              {subtitle.name}
              {subtitle.isDefault && (
                <Badge variant="secondary" className="ml-2">
                  Default
                </Badge>
              )}
            </CardTitle>
          </div>
          <div className="flex gap-1">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Info className="h-4 w-4" />
                  <span className="sr-only">Info</span>
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-96" align="end">
                <div className="grid gap-2">
                  <div className="space-y-1">
                    <h4 className="text-sm font-semibold">Subtitle Details</h4>
                    <div className="text-xs space-y-1">
                      <div>
                        <span className="font-medium">Movie:</span> {subtitle.movieInfo.title} (
                        {subtitle.movieInfo.year})
                      </div>
                      <div>
                        <span className="font-medium">IMDB:</span> {subtitle.movieInfo.imdbId}
                      </div>
                      <div>
                        <span className="font-medium">Douban:</span> {subtitle.movieInfo.doubanId}
                      </div>
                      <div>
                        <span className="font-medium">Downloads:</span> {subtitle.downloads}
                      </div>
                      <div>
                        <span className="font-medium">Source:</span> {subtitle.source}
                      </div>
                      <div className="pt-2 border-t mt-2">
                        <span className="font-medium">ID:</span> {detailedInfo.id}
                      </div>
                      <div>
                        <span className="font-medium">Path:</span> {detailedInfo.path}
                      </div>
                      <div>
                        <span className="font-medium">ASSRT Title:</span> {detailedInfo["assrt-title"]}
                      </div>
                      <div>
                        <span className="font-medium">ASSRT URL:</span> {detailedInfo["assrt-url"]}
                      </div>
                      <div>
                        <span className="font-medium">Timestamp:</span> {detailedInfo.timestamp}
                      </div>
                    </div>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div className="flex items-center gap-1">
            <FileText className="h-3.5 w-3.5 text-muted-foreground" />
            <span className="text-muted-foreground">File:</span> {fileName}
          </div>
          <div className="flex items-center gap-1">
            <Badge variant="outline" className="h-5 text-xs">
              {subtitle.format.toUpperCase()}
            </Badge>
            <Badge variant="outline" className="h-5 text-xs">
              {subtitle.language}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardFooter className="flex justify-between pt-0">
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handlePreview} disabled={isExtracting}>
            {isExtracting ? (
              "Extracting..."
            ) : (
              <>
                <Eye className="mr-2 h-4 w-4" />
                Preview
              </>
            )}
          </Button>

          <a
            href={getEncodedUrl(subtitle.url)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-9 px-3"
            onClick={(e) => e.stopPropagation()}
          >
            <Download className="mr-2 h-4 w-4" />
            Download
          </a>
        </div>

        <div className="flex gap-2">
          {onChangeLanguage && (
            <div className="w-40">
              <Select
                onValueChange={handleChangeLanguage}
                disabled={isChangingLanguage}
                defaultValue={subtitle.language}
              >
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="Change Language" />
                </SelectTrigger>
                <SelectContent>
                  {availableLanguages.map((lang) => (
                    <SelectItem key={lang} value={lang}>
                      {lang}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {!subtitle.isDefault && (
            <Button variant="secondary" size="sm" onClick={handleSetAsDefault} disabled={isSettingDefault}>
              {isSettingDefault ? (
                "Setting..."
              ) : (
                <>
                  <Star className="mr-2 h-4 w-4" />
                  Set as Default
                </>
              )}
            </Button>
          )}
        </div>
      </CardFooter>

      {isSelected && previewContent && (
        <CardContent className="pt-4 border-t mt-2">
          <div className="text-sm font-medium mb-2">Preview:</div>
          <div className="rounded-md bg-muted p-3 font-mono text-xs overflow-auto max-h-[400px]">
            <pre className="whitespace-pre-wrap">{previewContent}</pre>
          </div>
        </CardContent>
      )}
    </Card>
  )
}
