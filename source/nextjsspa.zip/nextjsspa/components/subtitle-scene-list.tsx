"use client"

import { useState } from "react"
import type { SubtitleScene } from "@/lib/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChevronDown, ChevronUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface SubtitleSceneListProps {
  scenes: SubtitleScene[]
}

export function SubtitleSceneList({ scenes }: SubtitleSceneListProps) {
  const [expandedScenes, setExpandedScenes] = useState<Record<string, boolean>>({})

  const toggleScene = (sceneId: string) => {
    setExpandedScenes((prev) => ({
      ...prev,
      [sceneId]: !prev[sceneId],
    }))
  }

  return (
    <div className="space-y-4">
      {scenes.map((scene) => {
        const isExpanded = expandedScenes[scene.id] || false

        return (
          <Card key={scene.id}>
            <CardHeader className="py-3 cursor-pointer" onClick={() => toggleScene(scene.id)}>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">
                  Scene {scene.startTime} - {scene.endTime}
                </CardTitle>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                  {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </Button>
              </div>
              <div className="text-sm text-muted-foreground">{scene.entries.length} entries</div>
            </CardHeader>
            <CardContent className={cn("pt-0", !isExpanded && "hidden")}>
              <div className="space-y-2">
                {scene.entries.map((entry) => (
                  <div key={entry.id} className="border-t pt-2">
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>
                        {entry.startTime} - {entry.endTime}
                      </span>
                      <span>#{entry.index}</span>
                    </div>
                    <div className="mt-1">{entry.text}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
