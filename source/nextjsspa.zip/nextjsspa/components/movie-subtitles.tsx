"use client"

import { useState } from "react"
// Removed useEffect and searchAssrtSubtitles import
import { SubtitleCard } from "@/components/subtitle-card"
import type { Subtitle } from "@/lib/types"

// Define props for the display component
interface SubtitleDisplayProps {
  subtitles: Subtitle[];
  isLoading: boolean;
  error: string | null;
  hasSearched: boolean;
  // TODO: Add callbacks for setAsDefault and changeLanguage if needed from parent
}

// Renamed function and updated props
export function SubtitleDisplay({
  subtitles,
  isLoading,
  error,
  hasSearched
}: SubtitleDisplayProps) {
  // Keep UI state local
  const [selectedSubtitle, setSelectedSubtitle] = useState<Subtitle | null>(null)
  const [expandedSubtitleId, setExpandedSubtitleId] = useState<string | null>(null)

  // Removed state and useEffect for fetching

  const handleSubtitleSelect = (subtitle: Subtitle) => {
    if (expandedSubtitleId === subtitle.id) {
      setExpandedSubtitleId(null)
    } else {
      setExpandedSubtitleId(subtitle.id)
    }
    setSelectedSubtitle(subtitle)
  }

  const handleSetAsDefault = (subtitle: Subtitle) => {
    // Update the local state to reflect the change immediately
    // TODO: This logic needs to be handled by the parent component (SubtitleHandler)
    // It might involve passing down a callback function prop.
    // For now, just log the action.
    console.log("Set as default requested for:", subtitle.id, subtitle.language);
    /*
    const updatedSubtitles = subtitles.map((sub) => {
      if (sub.language === subtitle.language) {
        return {
          ...sub,
          isDefault: sub.id === subtitle.id,
        }
      }
      return sub
    })

    // setSubtitles(updatedSubtitles) // Cannot modify prop directly
    */
  }

  const handleChangeLanguage = (subtitle: Subtitle, newLanguage: string) => {
    // Update the subtitle language
    // TODO: This logic needs to be handled by the parent component (SubtitleHandler)
    // It might involve passing down a callback function prop.
    // For now, just log the action.
    console.log("Change language requested for:", subtitle.id, "to", newLanguage);
    /*
    const updatedSubtitles = subtitles.map((sub) => {
      if (sub.id === subtitle.id) {
        return {
          ...sub,
          language: newLanguage,
          // If it was default in previous language, it's no longer default
          isDefault: false,
        }
      }
      return sub
    })

    // setSubtitles(updatedSubtitles) // Cannot modify prop directly
    */
  }

  // Group subtitles by language for better organization
  const subtitlesByLanguage = subtitles.reduce(
    (acc, subtitle) => {
      const language = subtitle.language
      if (!acc[language]) {
        acc[language] = []
      }
      acc[language].push(subtitle)
      return acc
    },
    {} as Record<string, Subtitle[]>,
  )

  // Get all languages and sort them to have English and Chinese first
  const languages = Object.keys(subtitlesByLanguage).sort((a, b) => {
    if (a === "English") return -1
    if (b === "English") return 1
    if (a === "CN_simplified" || a === "CN_traditional") return -1
    if (b === "CN_simplified" || b === "CN_traditional") return 1
    return a.localeCompare(b)
  })

  // Get all available languages for the language change dropdown
  const availableLanguages = [
    "English",
    "CN_simplified",
    "CN_traditional",
    "Español",
    "Français",
    "Deutsch",
    "Italiano",
    "Português",
    "Русский",
    "Arabic",
  ]

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold">Subtitles</h2>

      {isLoading && (
        <div className="py-8 text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
          <p className="mt-4 text-muted-foreground">Loading subtitles...</p>
        </div>
      )}

      {error && (
        <div className="rounded-md bg-red-50 p-4 dark:bg-red-900/20">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700 dark:text-red-400">{error}</p>
            </div>
          </div>
        </div>
      )}

      {!isLoading && !error && hasSearched && subtitles.length === 0 && (
        <div className="rounded-md bg-yellow-50 p-4 dark:bg-yellow-900/20">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-yellow-700 dark:text-yellow-400">No subtitles found for this movie.</p>
            </div>
          </div>
        </div>
      )}

      {!isLoading && !error && hasSearched && subtitles.length > 0 && (
        <div className="space-y-8">
          {languages.map((language) => (
            <div key={language} className="space-y-4">
              <h3 className="text-xl font-medium">{language}</h3>
              <div className="grid gap-6">
                {subtitlesByLanguage[language].map((subtitle) => (
                  <SubtitleCard
                    key={subtitle.id}
                    subtitle={subtitle}
                    onSelect={() => handleSubtitleSelect(subtitle)}
                    isSelected={expandedSubtitleId === subtitle.id}
                    onSetAsDefault={() => handleSetAsDefault(subtitle)}
                    availableLanguages={availableLanguages}
                    onChangeLanguage={(newLanguage) => handleChangeLanguage(subtitle, newLanguage)}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
