"use client"

import { useState } from "react"
import type { ParsedSubtitle, GroupingAlgorithm } from "@/lib/types"
import { exportSubtitle } from "@/lib/parser-service"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Download, Eye, Edit } from "lucide-react"
import { SubtitleEntryList } from "@/components/subtitle-entry-list"
import { SubtitleSceneList } from "@/components/subtitle-scene-list"

interface SubtitleParserProps {
  parsedSubtitle: ParsedSubtitle
}

export function SubtitleParser({ parsedSubtitle }: SubtitleParserProps) {
  const [selectedLanguage, setSelectedLanguage] = useState<string>(parsedSubtitle.languages[0])
  const [selectedAlgorithm, setSelectedAlgorithm] = useState<GroupingAlgorithm>("time-based")
  const [viewMode, setViewMode] = useState<"entries" | "scenes">("scenes")

  const filteredEntries = parsedSubtitle.entries.filter((entry) => entry.language === selectedLanguage)
  const filteredScenes = parsedSubtitle.scenes[selectedAlgorithm].filter((scene) => scene.language === selectedLanguage)

  const handleExport = () => {
    const content = exportSubtitle(filteredEntries, parsedSubtitle.format)

    // Create a blob and download it
    const blob = new Blob([content], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${parsedSubtitle.name}_${selectedLanguage}.${parsedSubtitle.format}`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>{parsedSubtitle.name}</CardTitle>
          <CardDescription>
            Format: {parsedSubtitle.format.toUpperCase()} • Entries: {filteredEntries.length} • Scenes:{" "}
            {filteredScenes.length}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4 mb-6">
            <div className="space-y-2">
              <label className="text-sm font-medium">Language</label>
              <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select language" />
                </SelectTrigger>
                <SelectContent>
                  {parsedSubtitle.languages.map((language) => (
                    <SelectItem key={language} value={language}>
                      {language}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">View Mode</label>
              <div className="flex">
                <Button
                  variant={viewMode === "entries" ? "default" : "outline"}
                  size="sm"
                  className="rounded-r-none"
                  onClick={() => setViewMode("entries")}
                >
                  <Eye className="mr-2 h-4 w-4" />
                  Entries
                </Button>
                <Button
                  variant={viewMode === "scenes" ? "default" : "outline"}
                  size="sm"
                  className="rounded-l-none"
                  onClick={() => setViewMode("scenes")}
                >
                  <Edit className="mr-2 h-4 w-4" />
                  Scenes
                </Button>
              </div>
            </div>

            {viewMode === "scenes" && (
              <div className="space-y-2">
                <label className="text-sm font-medium">Grouping Algorithm</label>
                <Select
                  value={selectedAlgorithm}
                  onValueChange={(value) => setSelectedAlgorithm(value as GroupingAlgorithm)}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select algorithm" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="time-based">Time-based</SelectItem>
                    <SelectItem value="character-based">Character-based</SelectItem>
                    <SelectItem value="dialog-based">Dialog-based</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          {viewMode === "entries" ? (
            <SubtitleEntryList entries={filteredEntries} />
          ) : (
            <SubtitleSceneList scenes={filteredScenes} />
          )}
        </CardContent>
        <CardFooter>
          <Button onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" />
            Export {selectedLanguage} Subtitles
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
