"use client"

import Image from "next/image"
import Link from "next/link"
import { useState, useEffect } from "react"
import { fetchRecommendedMovies } from "@/lib/subtitle-service"
import { cn } from "@/lib/utils"
import type { Movie } from "@/lib/types"

export function RecommendedMovies() {
  const [displayedMovies, setDisplayedMovies] = useState<Movie[]>([])
  const [isLoading, setIsLoading] = useState<boolean>(true)

  useEffect(() => {
    async function loadMovies() {
      try {
        setIsLoading(true)
        const movies = await fetchRecommendedMovies(10)
        setDisplayedMovies(movies)
      } catch (error) {
        console.error("Error loading recommended movies:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadMovies()
  }, []) // Empty dependency array ensures this runs only once on mount

  // Create a creative layout with different sizes
  const getRandomSize = (index: number) => {
    // Create a pattern of different sizes
    const patterns = [
      "col-span-1 row-span-1", // Small
      "col-span-2 row-span-1", // Wide
      "col-span-1 row-span-2", // Tall
      "col-span-2 row-span-2", // Large
    ]

    // Assign sizes based on index to create a visually interesting pattern
    if (index === 0 || index === 9) return patterns[3] // Large for first and last
    if (index === 2 || index === 6) return patterns[2] // Tall for some
    if (index === 4 || index === 8) return patterns[1] // Wide for some
    return patterns[0] // Small for the rest
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Recommended Movies</h2>
      </div>

      {isLoading ? (
        // Loading skeleton
        <div className="grid grid-cols-4 md:grid-cols-6 gap-3 auto-rows-[100px]">
          {Array.from({ length: 10 }).map((_, index) => (
            <div
              key={index}
              className={cn(
                "animate-pulse bg-gray-200 dark:bg-gray-800 rounded-lg",
                getRandomSize(index)
              )}
            />
          ))}
        </div>
      ) : displayedMovies.length > 0 ? (
        // Movies grid
        <div className="grid grid-cols-4 md:grid-cols-6 gap-3 auto-rows-[100px]">
          {displayedMovies.map((movie, index) => (
            <Link
              href={`/movie/${movie.id}`}
              key={movie.id}
              className={cn(
                "group relative overflow-hidden rounded-lg transition-all hover:shadow-lg",
                getRandomSize(index),
              )}
            >
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-all z-10"></div>
              <div className="absolute bottom-2 left-2 right-2 z-20">
                <h3 className="text-white font-medium text-sm truncate shadow-text">{movie.title}</h3>
                <p className="text-white/80 text-xs shadow-text">{movie.year}</p>
              </div>
              {movie.posterUrl ? (
                <Image
                  src={movie.posterUrl || "/placeholder.svg"}
                  alt={movie.title}
                  fill
                  className="object-cover transition-transform group-hover:scale-105"
                  sizes="(max-width: 768px) 50vw, 33vw"
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center">
                  <span className="text-white text-sm font-medium">{movie.title}</span>
                </div>
              )}
            </Link>
          ))}
        </div>
      ) : (
        // No movies found
        <div className="p-8 text-center">
          <p className="text-gray-500 dark:text-gray-400">No recommended movies available</p>
        </div>
      )}
    </div>
  )
}
