"use client"

import type React from "react"
import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { SearchResultsDropdown } from "@/components/search-results-dropdown"

export function SearchForm() {
  const router = useRouter()
  const [query, setQuery] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const [showResults, setShowResults] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!query.trim()) return

    setIsSearching(true)
    // Simulate search delay
    setTimeout(() => {
      setIsSearching(false)
      setShowResults(true)
    }, 500)
  }

  const handleResultSelect = (movieId: string) => {
    setShowResults(false)
    router.push(`/movie/${movieId}`)
  }

  const handleQueryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setQuery(e.target.value)
    if (e.target.value === "") {
      setShowResults(false)
    }
  }

  const handleClearSearch = () => {
    setQuery("")
    setShowResults(false)
    if (inputRef.current) {
      inputRef.current.focus()
    }
  }

  return (
    <div className="relative">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid gap-2">
          <Label htmlFor="query">Search for movies or TV shows</Label>
          <div className="flex gap-2">
            <Input
              id="query"
              placeholder="e.g. Inception"
              className="flex-1"
              value={query}
              onChange={handleQueryChange}
              ref={inputRef}
            />
            <Button type="submit" disabled={isSearching || !query.trim()}>
              {isSearching ? (
                "Searching..."
              ) : (
                <>
                  <Search className="mr-2 h-4 w-4" />
                  Search
                </>
              )}
            </Button>
          </div>
        </div>
      </form>

      {showResults && <SearchResultsDropdown onSelect={handleResultSelect} query={query} onClear={handleClearSearch} />}
    </div>
  )
}
