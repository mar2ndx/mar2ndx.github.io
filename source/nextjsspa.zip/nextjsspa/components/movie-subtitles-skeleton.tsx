import { Skeleton } from "@/components/ui/skeleton"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function MovieSubtitlesSkeleton() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold">Subtitles</h2>

      <Tabs defaultValue="database">
        <TabsList>
          <TabsTrigger value="database">Database Subtitles</TabsTrigger>
          <TabsTrigger value="internet">Internet Search</TabsTrigger>
        </TabsList>

        <TabsContent value="database" className="space-y-4 pt-4">
          {[1, 2].map((i) => (
            <div key={i} className="rounded-lg border p-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Skeleton className="h-6 w-1/3" />
                  <Skeleton className="h-10 w-24" />
                </div>
                <Skeleton className="h-4 w-1/4" />
                <Skeleton className="h-4 w-1/5" />
                <div className="mt-4 space-y-2">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                </div>
              </div>
            </div>
          ))}
        </TabsContent>

        <TabsContent value="internet" className="space-y-4 pt-4">
          <div className="flex justify-center py-8">
            <Skeleton className="h-10 w-48" />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
