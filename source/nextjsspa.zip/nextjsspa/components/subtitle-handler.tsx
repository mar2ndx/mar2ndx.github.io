"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { getSubtitlesFromDB, fetchAndStoreSubtitles } from "@/lib/subtitle-service"
import { SubtitleDisplay } from "@/components/movie-subtitles" // Use the refactored display component
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import type { Subtitle } from "@/lib/types"

type FetchStatus =
  | "idle"
  | "db_fetching"
  | "db_empty" // DB returned no results
  | "fetch_pending" // Waiting 3 seconds before auto-fetch
  | "fetch_loading" // Fetching from /fetch endpoint
  | "fetch_complete" // Fetch successful
  | "fetch_cancelled" // User cancelled auto-fetch
  | "fetch_error"

export function SubtitleHandler({ movieId }: { movieId: string }) {
  const [subtitles, setSubtitles] = useState<Subtitle[]>([])
  const [isLoading, setIsLoading] = useState(true) // Combined loading state
  const [error, setError] = useState<string | null>(null)
  const [fetchStatus, setFetchStatus] = useState<FetchStatus>("idle")
  const [limitInput, setLimitInput] = useState<string>("5") // Default limit
  const autoFetchTimerRef = useRef<NodeJS.Timeout | null>(null)

  // Function to fetch from DB
  const handleInitialFetch = useCallback(async () => {
    if (!movieId) return;
    console.log("Fetching subtitles from DB for:", movieId);
    setIsLoading(true)
    setError(null)
    setFetchStatus("db_fetching")
    try {
      const dbSubtitles = await getSubtitlesFromDB(movieId)
      setSubtitles(dbSubtitles)
      if (dbSubtitles.length === 0) {
        console.log("No subtitles found in DB, preparing auto-fetch...");
        setFetchStatus("db_empty")
        // Start timer for auto-fetch
        autoFetchTimerRef.current = setTimeout(() => {
          console.log("Auto-fetch timer expired, fetching...");
          handleFetchSubtitles() // Fetch with default limit
        }, 3000)
        setFetchStatus("fetch_pending") // Show cancel option while timer runs
      } else {
        console.log("Subtitles found in DB.");
        setFetchStatus("fetch_complete")
      }
    } catch (err) {
      console.error("Error fetching DB subtitles:", err)
      setError("Failed to load subtitles from database.")
      setFetchStatus("fetch_error")
    } finally {
      setIsLoading(false)
    }
  }, [movieId]) // Add movieId dependency

  // Function to fetch from /fetch endpoint
  const handleFetchSubtitles = useCallback(async (limit?: number) => {
    if (!movieId) return;
    console.log(`Fetching subtitles from /fetch endpoint for: ${movieId} with limit: ${limit ?? 'default'}`);
    setIsLoading(true)
    setError(null)
    setFetchStatus("fetch_loading")
    // Clear any existing timer just in case
    if (autoFetchTimerRef.current) {
      clearTimeout(autoFetchTimerRef.current)
      autoFetchTimerRef.current = null
    }
    try {
      const fetchedSubtitles = await fetchAndStoreSubtitles(movieId, limit)
      setSubtitles(fetchedSubtitles) // Update subtitles with fetched results
      if (fetchedSubtitles.length === 0) {
        console.log("Fetch endpoint returned no subtitles.");
        // Keep status as fetch_complete, but SubtitleDisplay will show "No subtitles"
      } else {
        console.log("Subtitles fetched successfully.");
      }
      setFetchStatus("fetch_complete")
    } catch (err) {
      console.error("Error fetching/storing subtitles:", err)
      setError("Failed to fetch subtitles from external source.")
      setFetchStatus("fetch_error")
    } finally {
      setIsLoading(false)
    }
  }, [movieId]) // Add movieId dependency

  // Initial fetch on component mount or when movieId changes
  useEffect(() => {
    handleInitialFetch()
    // Cleanup timer on unmount or if movieId changes
    return () => {
      if (autoFetchTimerRef.current) {
        clearTimeout(autoFetchTimerRef.current)
        autoFetchTimerRef.current = null
      }
    }
  }, [handleInitialFetch]) // Depend on the memoized fetch function

  const handleCancelFetch = () => {
    if (autoFetchTimerRef.current) {
      clearTimeout(autoFetchTimerRef.current)
      autoFetchTimerRef.current = null
      console.log("Auto-fetch cancelled by user.");
      setFetchStatus("fetch_cancelled")
    }
  }

  const handleLimitSubmit = (event: React.FormEvent) => {
    event.preventDefault()
    const limit = parseInt(limitInput, 10)
    if (!isNaN(limit) && limit > 0) {
      console.log(`User submitted fetch with limit: ${limit}`);
      handleFetchSubtitles(limit)
    } else {
      console.warn("Invalid limit input:", limitInput);
      setError("Please enter a valid positive number for the limit.")
      // Optionally reset status or keep input visible
    }
  }

  const hasSearched = fetchStatus === "fetch_complete" || fetchStatus === "db_empty" || fetchStatus === "fetch_cancelled" || fetchStatus === "fetch_error";

  return (
    <div className="space-y-6">
      {/* Conditional UI based on fetchStatus */}
      {fetchStatus === "db_empty" && (
        <div className="rounded-md bg-yellow-50 p-4 dark:bg-yellow-900/20 text-center">
          <p className="text-sm text-yellow-700 dark:text-yellow-400">
            No subtitles found in the database for this movie.
          </p>
        </div>
      )}

      {fetchStatus === "fetch_pending" && (
        <div className="rounded-md bg-blue-50 p-4 dark:bg-blue-900/20 text-center space-y-2">
          <p className="text-sm text-blue-700 dark:text-blue-400">
            Attempting to fetch subtitles from external sources in 3 seconds...
          </p>
          <Button variant="outline" size="sm" onClick={handleCancelFetch}>
            Cancel Fetch
          </Button>
        </div>
      )}

      {fetchStatus === "fetch_cancelled" && (
        <form onSubmit={handleLimitSubmit} className="rounded-md border p-4 space-y-3">
           <Label htmlFor="limit-input">Fetch with Limit (Optional)</Label>
           <div className="flex gap-2">
            <Input
              id="limit-input"
              type="number"
              min="1"
              value={limitInput}
              onChange={(e) => setLimitInput(e.target.value)}
              placeholder="e.g., 5"
              className="w-24"
            />
            <Button type="submit">Fetch Now</Button>
           </div>
           <p className="text-xs text-muted-foreground">
             Enter the maximum number of subtitles to fetch from external sources.
           </p>
        </form>
      )}

      {/* Render the display component */}
      <SubtitleDisplay
        subtitles={subtitles}
        isLoading={isLoading && (fetchStatus === 'db_fetching' || fetchStatus === 'fetch_loading')} // Only show loading during actual fetches
        error={error}
        hasSearched={hasSearched}
      />
    </div>
  )
}