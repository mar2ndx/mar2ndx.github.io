"use client"

import { useState } from "react"
import { ChevronDown, ChevronUp } from "lucide-react"

import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export function SubtitlePreview({ content, format }: { content: string; format: string }) {
  const [isExpanded, setIsExpanded] = useState(false)

  // Add syntax highlighting based on format
  const formatClass = format === "ass" ? "text-green-500" : "text-blue-500"

  return (
    <div className="space-y-2">
      <div className={cn("rounded-md bg-muted p-3 font-mono text-xs overflow-hidden", !isExpanded && "max-h-[150px]")}>
        <pre className="whitespace-pre-wrap">
          {format === "ass"
            ? content.split("\n").map((line, i) => (
                <div
                  key={i}
                  className={
                    line.startsWith("[")
                      ? "text-yellow-500"
                      : line.startsWith("Format:")
                        ? "text-purple-500"
                        : line.startsWith("Style:") || line.startsWith("Dialogue:")
                          ? "text-green-500"
                          : ""
                  }
                >
                  {line}
                </div>
              ))
            : content.split("\n").map((line, i) => (
                <div
                  key={i}
                  className={
                    /^\d+$/.test(line.trim())
                      ? "text-yellow-500"
                      : /\d\d:\d\d:\d\d,\d\d\d -->/.test(line)
                        ? "text-purple-500"
                        : ""
                  }
                >
                  {line}
                </div>
              ))}
        </pre>
      </div>
      <Button variant="ghost" size="sm" className="w-full justify-center" onClick={() => setIsExpanded(!isExpanded)}>
        {isExpanded ? (
          <>
            <ChevronUp className="mr-2 h-4 w-4" />
            Show Less
          </>
        ) : (
          <>
            <ChevronDown className="mr-2 h-4 w-4" />
            Show More
          </>
        )}
      </Button>
    </div>
  )
}
