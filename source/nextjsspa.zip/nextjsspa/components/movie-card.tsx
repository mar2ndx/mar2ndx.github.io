import Link from "next/link"
import Image from "next/image"
import type { Movie } from "@/lib/types"
import { Card } from "@/components/ui/card"

export function MovieCard({ movie }: { movie: Movie }) {
  return (
    <Link href={`/movie/${movie.id}`} className="block">
      <Card className="overflow-hidden h-full transition-all hover:shadow-md">
        {movie.posterUrl ? (
          <div className="aspect-[2/3] relative">
            <Image
              src={movie.posterUrl || "/placeholder.svg"}
              alt={`${movie.title} poster`}
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            />
          </div>
        ) : (
          <div className="aspect-[2/3] flex items-center justify-center bg-muted p-4">
            <div className="text-center">
              <div className="text-2xl font-bold">{movie.imdbId}</div>
              <div className="text-xl">{movie.title}</div>
            </div>
          </div>
        )}
        <div className="p-4">
          <h3 className="font-semibold text-center truncate">{movie.title}</h3>
        </div>
      </Card>
    </Link>
  )
}
